package com.cg.core.hbms.logger;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class HBMSLogger 
{

	public static Logger log= Logger.getLogger(HBMSLogger.class);
	
	public HBMSLogger()
	{
		PropertyConfigurator.configure("log4j.properties");
	}
	
	
	public static Logger getLog()
	{
		return log;
	}
	
}
