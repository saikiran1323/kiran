package com.cg.core.hbms.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import com.cg.core.hbms.bean.Booking;
import com.cg.core.hbms.bean.Hotel;
import com.cg.core.hbms.bean.Room;
import com.cg.core.hbms.exception.HBMSException;
import com.cg.core.hbms.service.HBMSAdminServiceImpl;
import com.cg.core.hbms.service.HBMSUserServiceImpl;
import com.cg.core.hbms.service.IHBMSAdminService;
import com.cg.core.hbms.service.IHBMSUserService;

import static java.time.temporal.ChronoUnit.DAYS;

public class CustomerUI 
{

	public static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	static String choice;
	
	static IHBMSAdminService adminService = new HBMSAdminServiceImpl();
	static IHBMSUserService userService = new HBMSUserServiceImpl();

	public static void UserHomePage() 
	{
		System.out.println("***********************CUSTOMER OPERATIONS*********************");

		while (true)
		{
			System.out.println("1.Search for hotel Rooms");
			System.out.println("2.Book hotel Rooms");
			System.out.println("3.View Booking Details");
			System.out.println("4.Logout");

			System.out.println("Please Enter your choice:");
			
		
			try 
			{
				choice = reader.readLine();

				switch (choice) {
				case "1":

					System.out.println("****************LIST OF HOTELS**********************");
					
					showHotelsCateLog();
				
					System.out.println("****************SEARCH HOTEL ROOM(S)**********************");
					
					getHotelRooms();
					
					
					break;
				case "2":

					System.out.println("*******************BOOK HOTEL ROOM(S)*******************");
					
					performBooking();
					
					
					break;
				case "3":

					System.out.println("**********************VIEW BOOKING DETAILS**********************");
					getBookingStatus();
				
					break;
				case "4":
					Client.homePage();
					break;

				default:
					System.err.println("Please enter valid option");
					UserHomePage();
					break;
				}

			}
			catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		


	}

	private static void performBooking() 
	{
		
		//userId=?
		//hotelcatelog roomdetalsByid (which room no) how many days check in check out adults childeren ask summury  if perfect add to dB else ask again then return booking Id amount 
		
		ArrayList<Integer> bookRooms = new ArrayList<Integer>();
		int roomCount=0;
		try 
		{
			System.out.println("ENTER YOUR USER ID:");
			int  userId = Integer.parseInt(reader.readLine());

			if(userService.isValidUser(userId))
			{
				showHotelsCateLog();
				
				int hotelId=getHotelRooms();
				
				System.out.println(hotelId);
		
				System.out.println("**********************************************************************");
				
				roomCount=getRoomCount(hotelId);
				
				
				System.out.println("HOW MANY ROOMS DO YOU WANT TO BOOK :");
				
				int bookRoomCount= Integer.parseInt(reader.readLine());
				
				if(bookRoomCount<=roomCount)
				{
				
					for (int i = 1; i <= bookRoomCount; i++) 
					{
					
					System.out.println("ENTER ROOM ID YOU WANT TO BOOK :");
					
					bookRooms.add(Integer.parseInt(reader.readLine()));
						
					}
					
					Booking booking=getBookingDetails();
					
					System.out.println(booking);
					
					showBookingSummary(userId,bookRooms,booking);
				}
				else
				{
					System.err.println("SORRY CANNOT BOOK "+ bookRoomCount +" ROOM(S)");
				}
			
			}
			else
			{
			
				System.err.println("Please Registration First ");
			}
				
		} 
		catch (HBMSException e) 
		{
			System.err.println(e.getMessage());
		} catch (IOException e) 
		{
			System.err.println(e.getMessage());
		}
		
		
		}

	private static void showBookingSummary(int userId,ArrayList<Integer>bookRooms,Booking booking)
	{
		
		System.out.println("******************************SUMMARY OF BOOKING*****************************");
		
		System.out.println("\nENTERED USER ID :"+userId);
		
		System.out.println("\nNO OF ROOMS YOU WANT TO BOOK :"+bookRooms.size());
		
		Iterator<Integer> it = bookRooms.iterator();
		
		while(it.hasNext())
		{
			System.out.println("ROOM NO :"+it.next());
		}
		
		System.out.println("\nCHECK IN DATE :"+booking.getBookedFrom());
		
		System.out.println("\nCHECK OUT DATE :"+booking.getBookedTo());
		
		System.out.println("\nNO OF ADULTS :"+booking.getNoOfAdults());
		
		System.out.println("\nNO OF CHILDEREN :"+booking.getNoOfchildren());
		
		System.out.println("\nDO YOU WANT TO MODIFY DETAILS : Y/N");
		
		try 
		{
			String ans = reader.readLine();
			
			
			if(ans.equalsIgnoreCase("y"))
			{
				System.out.println("*****************************************************************");
				performBooking();
			}
			else if(ans.equalsIgnoreCase("n"))
			{
				
				long days = DAYS.between(booking.getBookedFrom(),booking.getBookedTo());
				 
				System.out.println(days);
				
				double bookingAmount=userService.getBookingAmount(bookRooms);
				
				double finalBookingAmount = bookingAmount*days;
				
				System.out.println("YOUR BOOKING AMOUNT IS :"+finalBookingAmount);
				
				
				userService.addBookingDetails(userId,bookRooms,booking,finalBookingAmount);

		
			}
			else
			{
				System.err.println("Please Enter valid Choice !");
			}
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

	private static void showHotelsCateLog() 
	{
		try 
		{
			HashMap<Integer, Hotel> hotelList = adminService
					.showAllHotels();

			Set<Integer> keys = hotelList.keySet();

			System.out.println("Hotel Id"+"\t\t"+"Hotel Name"+"\t\t"+"Hotel Address"+"\t\t\t"+"Hotel Email"+"\t\t"+"Hotel Contact");

			for (Integer key : keys) 
			{
				Hotel hotels = hotelList.get(key);
				
				System.out.println(hotels.getHotelId()+"\t\t\t"+ hotels.getHotelName()+"\t\t\t"+ hotels.getAddress() +"\t\t\t"+ hotels.getEmail() +"\t\t"+ hotels.getPhoneNo1());
			}
			
		}
		catch (HBMSException e) 
		{
			System.out.println(e.getMessage());
		}
		
		
	}
	
	
	public static int getHotelRooms()
	{
		int hotelId = 0;
		int count=0;
		try 
		{

			HashMap<Integer,Room>roomDetails =new HashMap<Integer,Room>();
			
			System.out.println("Enter Hotel ID from above Catelog To Get The Room(s) Details");
			System.out.println();
			 hotelId = Integer.parseInt(reader.readLine());
			 
			 String hotelName=userService.getHotelNameById(hotelId);
		
			roomDetails=userService.serachHotelRoomByHotelId(hotelId);
			
			
			
			System.out.println("----------------ROOM DETAILS OF "+hotelName+"----------------");

		  count=roomDetails.size();
			
			Set<Integer> roomKeys = roomDetails.keySet();
			
			System.out.println("ROOM ID"+"\t\t"+"ROOM NO"+"\t\t"+"ROOM TYPE"+"\t"+"PER NIGHT RATE");
			
			for (Integer key : roomKeys) 
			{
				Room room = roomDetails.get(key);
				System.out.println(room.getRoomId()+"\t\t"+room.getRoomNo()+"\t\t"+room.getRoomType()+"\t\t"+room.getPerNightRate()+"\t\t");
			}
			
			System.out.println("NO. OF ROOMS :"+count);
		    
		}
		catch (HBMSException e) 
		{
			
			System.out.println(e.getMessage());
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return hotelId;

	}
	public static void getBookingStatus()
	{
		
		try
		{
			System.out.println("Enter Booking Id : ");
			int bookingId = Integer.parseInt(reader.readLine());
			
			ArrayList bookingStatus=userService.viewBookingStatus(bookingId);
			
			if(bookingStatus==null)
			{
				throw new HBMSException("Cannot find the details of booking Id "+bookingId);
			}
			
			/*System.out.println(booking);*/
			
			System.out.println("BOOKING ID"+"\t"+"BOOKED FROM"+"\t\t"+"BOOKED TO"+"\t\t"+"NO OF ADULTS"+"\t"+"NO OF CHILDEREN"+"\t"+"AMOUNT");
			
			System.out.println(bookingStatus.get(0)+"\t\t"+bookingStatus.get(1)+"\t\t"+bookingStatus.get(2)+"\t\t"+bookingStatus.get(3)+"\t\t"+bookingStatus.get(4)+"\t\t"+bookingStatus.get(5));
		
		} 
		catch (HBMSException e)
		{
			System.out.println(e.getMessage());
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	
	public static Booking getBookingDetails()
	{
		Booking booking = new Booking();
		DateTimeFormatter dtf ;
		try
		{
		
			System.out.println("Enter check in date in(dd-mm-yyy) Format:");
			String checkIn = reader.readLine();
			
			dtf=DateTimeFormatter.ofPattern("d-M-yyyy");
			
			LocalDate bookFrom= LocalDate.parse(checkIn,dtf);
				
			System.out.println("Enter check out date in(dd-mm-yyy) Format:");
			String checkOut =reader.readLine();
			
			dtf=DateTimeFormatter.ofPattern("d-M-yyyy");
			
			LocalDate bookTo= LocalDate.parse(checkOut,dtf);
			
			if(bookFrom.isBefore(bookTo))
			{
				System.out.println("Enter no.of adults:");
				int noOfAdults=Integer.parseInt(reader.readLine());
				
				System.out.println("Enter no.of Childern:");
				int noOfchildren=Integer.parseInt(reader.readLine());
				
				booking.setBookedFrom(bookFrom);
				booking.setBookedTo(bookTo);
				booking.setNoOfAdults(noOfAdults);
				booking.setNoOfchildren(noOfchildren);
			}
			else
			{
				throw new HBMSException("Please Enter valid dates for Check In and Check Out.");
			}
			
		}
		catch (Exception e)
		{
			System.err.println(e.getMessage());
			System.err.println("Please Enter a valid data in format as mentioned.");
		}
		return booking;
		
	}
	
	
	
	public static int getRoomCount(int hotelId)
	{
		
		HashMap<Integer, Room> roomList = new HashMap<Integer, Room>();
		int roomCount=0;
		
		try 
		{
			roomList=userService.serachHotelRoomByHotelId(hotelId);
			
			roomCount=roomList.size();
		}
		catch (HBMSException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return roomCount;
		
	}
	

}
