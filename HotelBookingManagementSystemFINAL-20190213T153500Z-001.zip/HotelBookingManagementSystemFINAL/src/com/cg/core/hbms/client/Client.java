package com.cg.core.hbms.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.cg.core.hbms.bean.Login;
import com.cg.core.hbms.bean.User;
import com.cg.core.hbms.dao.IHBMSAdminDao;
import com.cg.core.hbms.exception.HBMSException;
import com.cg.core.hbms.service.HBMSAdminServiceImpl;
import com.cg.core.hbms.service.HBMSUserServiceImpl;
import com.cg.core.hbms.service.IHBMSAdminService;
import com.cg.core.hbms.service.IHBMSUserService;

public class Client
{
	public static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	static String choice;
	private static String username;
	private static String password;
	static IHBMSAdminService adminService = new HBMSAdminServiceImpl();
	
	static IHBMSUserService userService = new HBMSUserServiceImpl();
	
	public static void main(String[] args) {

		String choice = homePage();
		while(true)
		{
			
		switch (choice) {
		
		case "1":

			System.out.println("*****************LOGIN PORTAL******************");
			String role = getLoggedIn();
		
			System.out.println(role);
			switch (role) {
			case "customer":

				CustomerUI.UserHomePage();
				break;
			case "employee":
	
				CustomerUI.UserHomePage();
				break;
			case "admin":

				AdminUI.adminHomePage();
				break;
				
			default:
				System.err.println("enter valid login details");
				choice=homePage();
				break;
			
			}
			
			////////////////////////////////////////////////////////////////////////////
		break;
		case "2":
			System.out.println("*****************REGISTER PORTAL******************");
			User user=getUserDetails();
			Login login=getLoginDetails();
			try 
			{
				int userId = userService.addUser(user, login);
			
				System.out.println("USER REGISTERED SUCCESSFULLY WITH USERID : " + userId);
			} 
			catch (HBMSException e)
			{
				System.err.println(e.getMessage());
				e.printStackTrace();
			}
			choice=homePage();
		case "3":

			break;

		case "4":

			System.exit(0);
			break;

		default:
			System.err.println("outer case:Please enter valid option");
			homePage();
			break;
		}
		}
			
		}
		

	private static Login getLoginDetails() {
		// TODO Auto-generated method stub
		System.out.println("------------LOGIN DETAILS-------------");
	 	String type=null;
	 	Login login= null;
		try{
			System.out.println("ENTER YOUR UNIQUE USERNAME:");
			String username=reader.readLine();
			System.out.println("ENTER YOUR PASSWORD:");
			String password=reader.readLine();
			System.out.println("Select type to Login");
			System.out.println("1.Customer");
			System.out.println("2.Employee");
			choice = reader.readLine();
	
			if (choice.equalsIgnoreCase("1"))
			{
				type = "customer";
			} 
			else if (choice.equalsIgnoreCase("2"))
			{
				type = "employee";
			}
			login = new Login();
			login.setUsername(username);
			login.setPassword(password);
			login.setRole(type);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return login;

	}


	private static User getUserDetails() {
		// TODO Auto-generated method stub
		System.out.println("ENTER YOUR FIRST NAME:");
		User user=null;
		try {
			String fname= reader.readLine();
		
		
		System.out.println("ENTER YOUR LAST NAME:");
		
		String lname= reader.readLine();
		
		System.out.println("ENTER YOUR ADDRESS:");
		String address= reader.readLine();
		
		System.out.println("ENTER YOUR MOBILE NO:");
		String mobileNo= reader.readLine();
		
		System.out.println("ENTER YOUR PHONE NO:");
		String phoneNo= reader.readLine();
		
		System.out.println("ENTER YOUR EMAIL ID:");
		String email= reader.readLine();
		

		 user= new User();
		user.setFirstName(fname);
		user.setLastName(lname);
		user.setMobileNo(mobileNo);
		user.setPhoneNo(phoneNo);
		user.setAddress(address);
		user.setEmail(email);
		
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}


	public static String homePage()
	{
		System.out.println("-------------WELCOME TO TRIPPER'S CHOICE-------------");
		
		System.out.println("1.Login");
		System.out.println("2.Register");
		System.out.println("3.Search For Hotel Room(s)");
		System.out.println("4.Exit");

		System.out.println("Please Enter your choice:");
		
		try
		{
			choice = reader.readLine();
			int c = Integer.parseInt(choice);
			while(c>4 || c<1)
			{
				System.out.println("Invalid Input. Enter again");
				choice = reader.readLine();
				c = Integer.parseInt(choice);
			}
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return choice;
	}
	
	
	public static String  getLoggedIn() {

		String role = null;
		
		try
		{
			System.out.println("Enter your Username:");
			username = reader.readLine();
			
			System.out.println("Enter your Password:");
			password = reader.readLine();

			role=adminService.getRole(username, password);
			
			
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return role;
	}
}

	