package com.cg.core.hbms.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Set;

import com.cg.core.hbms.bean.Booking;
import com.cg.core.hbms.bean.Hotel;
import com.cg.core.hbms.bean.Room;
import com.cg.core.hbms.bean.User;
import com.cg.core.hbms.exception.HBMSException;
import com.cg.core.hbms.service.HBMSAdminServiceImpl;
import com.cg.core.hbms.service.IHBMSAdminService;

public class AdminUI 
{
	public static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	static String choice;
	static int hotelId;
	static IHBMSAdminService adminService = new HBMSAdminServiceImpl();

	
	public static void adminHomePage()
	{
		System.out.println("***********************ADMIN OPERATIONS*********************");
		
		while(true){
		System.out.println("1.Perform Hotel Managemet");
		System.out.println("2.Perform Room Managemet");
		System.out.println("3.Generate Reports");
		System.out.println("4.Logout");
		
		System.out.println("Please Enter your choice:");
		
		try 
		{
			choice = reader.readLine();

			switch (choice) {
			case "1":

				System.out.println("****************Perform Hotel Managemet**********************");
				performHotelManagment();
				
				break;
			case "2":

				System.out.println("*******************Perform Room Managemet*******************");
				
				performRoomManagement();
				break;
			case "3":

				System.out.println("**********************Generate Reports**********************");
				
				generateReports();
				break;
			case "4":
				Client.homePage();
				break;

			default:
				System.err.println("Please enter valid option");
				adminHomePage();
				break;
			}

		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	}
	private static void generateReports() 
	{
		while(true){
		int count = 0;
		
		
		System.out.println("1.View List of Hotels");
		System.out.println("2.View Bookings of specific hotel");
		System.out.println("3.View guest list of specific hotel");
		System.out.println("4.View bookings for specified date");
		System.out.println("5.Back");
		
		System.out.println("Please Enter your choice:");
		
		try 
		{
			choice= reader.readLine();
			
			switch (choice) {
			case "1":
				
				System.out.println("************************LIST OF HOTELS*************************");
				
				HashMap<Integer, Hotel> hotelList = new HashMap<Integer, Hotel>();
				
				hotelList=adminService.showAllHotels();
				
				Set<Integer> hotelkeys = hotelList.keySet();
				
				System.out.println("HOTEL ID"+"\t"+"HOTEL NAME"+"\t"+"HOTEL ADDRESS"+"\t\t"+"HOTEL EMAIL"+"\t\t"+"HOTEL CONTACT"+"\t\t"+"HOTEL RATING"+"\t");
				
				for (Integer key : hotelkeys) 
				{
					Hotel hotels = hotelList.get(key);
					System.out.println(hotels.getHotelId()+"\t\t"+hotels.getHotelName()+"\t\t"+hotels.getAddress()+"\t\t"+hotels.getEmail()+"\t\t"+hotels.getPhoneNo1()+"\t\t"+hotels.getRating());
				}
				
				count =hotelList.size();
				
				System.out.println("NO. OF HOTELS :"+count);
				
				break;
			case "2":
				HashMap<Integer, Booking> bookMap = new HashMap<Integer, Booking>();
				System.out.println("ENTER HOTEL ID :");
				hotelId=Integer.parseInt(reader.readLine());
				 
				bookMap=adminService.getHotelBooking(hotelId);
				count=bookMap.size();
				
				Set<Integer> bookKeys = bookMap.keySet();
				
				System.out.println("BOOKING ID"+"\t"+"BOOKED FROM"+"\t"+"BOOKED TO"+"\t"+"NO OF ADULTS"+"\t"+"NO OF CHILDEREN"+"\t\t"+"AMOUNT"+"\t\t");
				
				for (Integer key : bookKeys) 
				{
					Booking booking = bookMap.get(key);
					System.out.println(booking.getBookingId()+"\t\t"+booking.getBookedFrom()+"\t\t"+booking.getBookedTo()+"\t\t"+booking.getNoOfAdults()+"\t\t"+booking.getNoOfchildren()+"\t\t"+booking.getAmount()+"\t\t");
				}
				
				System.out.println("NO. OF BOOKINGS :"+count);
				
				
				break;
			case "3":

				System.out.println("************************GUEST LIST OF SPECIFIC HOTEL*************************");
				HashMap<Integer, User> guestList = new HashMap<Integer, User>();
				
				System.out.println("ENTER HOTEL ID :");
				hotelId=Integer.parseInt(reader.readLine());
				
				guestList=adminService.getUserList(hotelId);
				
				count=guestList.size();
				
				Set<Integer> guestKeys = guestList.keySet();
				
				System.out.println("USER ID"+"\t"+"USER NAME"+"\t"+"FIRST NAME"+"\t"+"LAST NAME"+"\t"+"USER ADDRESS"+"\t\t"+"USER MOBILE NO"+"\t\t"+"USER PHONE NO"+"\t\t"+"USER EMAIL"+"\t");
				
				for (Integer key : guestKeys) 
				{
					User user = guestList.get(key);
					System.out.println(user.getUserId()+"\t\t"+user.getUsername()+"\t\t"+user.getFirstName()+"\t\t"+user.getLastName()+"\t\t"+user.getAddress()+"\t\t"+user.getMobileNo()+"\t\t"+user.getPhoneNo()+"\t\t"+user.getEmail());
				}
				
				System.out.println("NO. OF GUESTS :"+count);
				
				break;
			case "4":

				System.out.println("************************BOOKINGS OF SPECIFIC DATE*************************");
				
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("d-M-yyyy");
				HashMap<Integer, Booking> bookingList = new HashMap<Integer, Booking>();
				
				System.out.println("ENTER SPECIFICT DATE IN (dd-mm-yyyy) FORMAT:");
				String date = reader.readLine();
				
				LocalDate specificDate = LocalDate.parse(date, dtf);
				
				bookingList=adminService.getBookingByDate(specificDate);
				
				Set<Integer> bookingKeys = bookingList.keySet();
				
				System.out.println("BOOKING ID"+"\t"+"BOOKED FROM"+"\t\t"+"BOOKED TO"+"\t"+"NO OF ADULTS"+"\t"+"NO OF CHILDEREN"+"\t\t"+"AMOUNT"+"\t\t");
				
				for (Integer key : bookingKeys) 
				{
					Booking booking = bookingList.get(key);
					System.out.println(booking.getBookingId()+"\t\t"+booking.getBookedFrom()+"\t"+booking.getBookedTo()+"\t"+booking.getNoOfAdults()+"\t"+booking.getNoOfchildren()+"\t1"+booking.getAmount()+"\t\t");
				}
				count=bookingList.size();
				System.out.println("NO. OF GUESTS :"+count);
				
				
				break;
			case "5":
				adminHomePage();
				break;
			
			default:
				System.err.println("Please enter valid option");
				generateReports();
				break;
			}
		}
		catch (Exception e) 
		{
			// TODO: handle exception
		}
		}
	}

	private static void performRoomManagement()
	{
		
		while(true){
		System.out.println("1.Add Room(s)");
		System.out.println("2.Update Room(s)");
		System.out.println("3.Delete Room(s)");
		System.out.println("4.Back");
		
		System.out.println("Please Enter your choice:");
		
		try 
		{
			choice=reader.readLine();
			
			switch (choice) {
			case "1":
				//add room

				System.out.println("************ADD ROOM************");
				int hotelId;
				int count;
				
				HashMap<Integer, Hotel> hotelList=adminService.showAllHotels();
				
				Set<Integer> hotelkeys = hotelList.keySet();
				
				System.out.println("HOTEL ID"+"\t"+"HOTEL NAME"+"\t"+"HOTEL ADDRESS"+"\t\t"+"HOTEL EMAIL"+"\t\t"+"HOTEL CONTACT"+"\t\t"+"HOTEL RATING"+"\t");
				
				for (Integer key : hotelkeys) 
				{
					Hotel hotels = hotelList.get(key);
					System.out.println(hotels.getHotelId()+"\t\t"+hotels.getHotelName()+"\t\t"+hotels.getAddress()+"\t\t"+hotels.getEmail()+"\t\t"+hotels.getPhoneNo1()+"\t\t"+hotels.getRating());
				}
				
				count =hotelList.size();
				
				System.out.println("NO. OF HOTELS :"+count);
				
				System.out.println("ENTER HOTEL ID :");
				hotelId = Integer.parseInt(reader.readLine());
				Room room = addRoomDetails();
				
				int roomId=adminService.addRoom(room, hotelId);
				
				System.out.println("ROOM ADDED SUCCESSFULLY WITH ROOM ID "+roomId);
				
				
				break;
			case "2":
				//update room
				//showCaralog method will come
				System.out.println("************UPDATE ROOM************");
		
				System.out.println("ENTER ROOM ID :");
				roomId=Integer.parseInt(reader.readLine());
				
				updateRoomDetails(roomId);
				
				break;
			case "3":
				//delete room
				
				System.out.println("************DELETE ROOM************");
				System.out.println("ENTER ROOM ID :");
				roomId=Integer.parseInt(reader.readLine());
				
				adminService.deleteRoom(roomId);
				
				System.out.println("ROOM ID "+roomId+" DELETED SUCCESSFULLY ");
				
				break;
			case "4":
				adminHomePage();
				break;

			default:
				System.err.println("Please enter valid option");
				performRoomManagement();
				break;
			}
		} 
		catch (Exception e) 
		{
			// TODO: handle exception
		}
		}
	}

	private static void updateRoomDetails(int roomId)
 {
		
		int roomNo;
		String roomType;
		float perNightRate;
		
		while(true){
		try 
		{
			System.out.println("1.Room No ");
			System.out.println("2.Room Type ");
			System.out.println("3.Room Per Night Rate ");
			System.out.println("3.Back ");
			System.out.println("Enter your choice : ");
			
			choice = reader.readLine();
			
			switch (choice) {
			case "1":

				System.out.println("ENTER NEW ROOM NO :");
				roomNo=Integer.parseInt(reader.readLine());
				
				adminService.updateRoomNo(roomId,roomNo);
				
				
				
				break;
			case "2":

				System.out.println("ENTER NEW ROOM TYPE :");
				roomType=reader.readLine();
				
				adminService.updateRoomType(roomId, roomType);
				
				break;
			case "3":

				System.out.println("ENTER PER NIGHT RATE :");
				perNightRate=Float.parseFloat(reader.readLine());
				
				adminService.updateRoomPerNightRate(roomId, perNightRate);
				
				break;
			case "4":
				adminHomePage();
				break;

			default:
				System.err.println("Please enter valid option");
				updateRoomDetails(roomId);
				break;
			}	
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
		}
		
	}

	private static Room addRoomDetails() 
	{
		int roomNo;
		String roomType;
		float perNightRate;
		int isAvailable;
		
		
		Room room = new Room();
		while(true){
		try
		{
			System.out.println("ENTER ROOM NO :");
			roomNo = Integer.parseInt(reader.readLine());
			
			System.out.println("ENTER ROOM TYPE :");
			roomType=reader.readLine();
			
			System.out.println("ENTER ROOM PER NIGHT RATE :");
			perNightRate=Float.parseFloat(reader.readLine());
			
			room.setRoomNo(roomNo);
			room.setRoomType(roomType);
			room.setPerNightRate(perNightRate);
	
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		return room;
	}
	}
	private static void performHotelManagment()
	{
		while(true){
		System.out.println("1.Add Hotel");
		System.out.println("2.Update Hotel");
		System.out.println("3.Delete Hotel");
		System.out.println("4.Exit");
		
		System.out.println("Please Enter your choice:");
		
		try 
		{
			choice= reader.readLine();
			
			switch (choice) {
			case "1":
				//add hotel
				System.out.println("************ADD HOTEL************");
				
				Hotel hotel = addHotelDetails();
				
				int hotelId = adminService.addHotel(hotel);
				
				System.out.println("Hotel Added with Hotel ID: "+hotelId);
				
				break;
			case "2":

				//update hotel
				//showCaralog method will come
				System.out.println("************UPDATE HOTEL************");
				System.out.println("ENTER HOTEL ID :");
				hotelId=Integer.parseInt(reader.readLine());
				
				updateHotelDetails(hotelId);
				
				break;
			case "3":
				//Delete hotel
				System.out.println("************DELETE HOTEL************");
				System.out.println("ENTER HOTEL ID :");
				hotelId=Integer.parseInt(reader.readLine());
				
				adminService.deleteHotel(hotelId);
				
				
				
				break;
			case "4":
				
				performHotelManagment();
				break;

			default:
				System.err.println("Please enter valid option");
				performHotelManagment();
				break;
			}
			
			
		}
		
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	}
	
	public static Hotel addHotelDetails()
	{
	
		String hotelName;
		String address;
		String description;
		float avgRatePerNight;
		String phoneNo1;
		String phoneNo2;
		String email;
		String fax;
		int rating;
		while(true){
		Hotel hotel = new Hotel();
		
		try 
		{
			
			System.out.println("ENTER HOTEL NAME :");
			hotelName=reader.readLine();
			
			System.out.println("ENTER HOTEL ADDRESS :");
			address=reader.readLine();
			
			System.out.println("ENTER HOTEL DESCRIPTION :");
			description=reader.readLine();
			
			System.out.println("ENTER HOTEL AVERAGE RATE PER NIGHT :");
			avgRatePerNight=Float.parseFloat(reader.readLine());
	
			System.out.println("ENTER HOTEL PHONE NO 1 :");
			phoneNo1=reader.readLine();
			
			System.out.println("ENTER HOTEL PHONE NO 2 :");
			phoneNo2=reader.readLine();
			
			System.out.println("ENTER HOTEL RATING :");
			rating=Integer.parseInt(reader.readLine());
			
			System.out.println("ENTER HOTEL EMAIL ID :");
			email=reader.readLine();
			
			System.out.println("ENTER HOTEL FAX NO :");
			fax=reader.readLine();
			
			hotel.setHotelName(hotelName);
			hotel.setAddress(address);
			hotel.setDescription(description);
			hotel.setAvgRatePerNight(avgRatePerNight);
			hotel.setPhoneNo1(phoneNo1);
			hotel.setPhoneNo2(phoneNo2);
			hotel.setRating(rating);
			hotel.setEmail(email);
			hotel.setFax(fax);
			
			
			
		} catch (Exception e) 
		{
			// TODO: handle exception
		}
		
		return hotel;
	
	}
	}
	
	public static void updateHotelDetails(int hotelId)
	{

		String hotelName;
		String address;
		String description;
		float avgRatePerNight;
		String phoneNo1;
		String phoneNo2;
		String email;
		String fax;
		int rating;
		while(true){
		try 
		{
		System.out.println("1.HOTEL NAME :");
		System.out.println("2.HOTEL ADDRESS :");
		System.out.println("3.HOTEL DESCRIPTION :");
		System.out.println("4.HOTEL AVERAGE RATE PER NIGHT :");
		System.out.println("5.HOTEL PHONE NO 1 :");
		System.out.println("6.HOTEL PHONE NO 2 :");
		System.out.println("7.HOTEL RATING :");
		System.out.println("8.HOTEL EMAIL ID :");
		System.out.println("9.HOTEL FAX NO :");
		System.out.println("10.EXIT ");
		
		System.out.println("Please Enter your choice:");
		
		choice=reader.readLine();
		
			switch (choice) {
			case "1":

				System.out.println("ENTER NEW HOTEL NAME :");
				hotelName=reader.readLine();
				
				adminService.updateHotelName(hotelId, hotelName);
				
				break;
			case "2":

				System.out.println("ENTER NEW HOTEL ADDRESS :");
				address=reader.readLine();
				
				adminService.updateHotelAddress(hotelId, address);
				
				break;

			case "3":

				System.out.println("ENTER NEW HOTEL DESCRIPTION :");
				description=reader.readLine();
				
				adminService.updateHotelDescription(hotelId, description);
				
				
				break;

			case "4":

				System.out.println("ENTER NEW HOTEL AVERAGE RATE PER NIGHT :");
				avgRatePerNight=Float.parseFloat(reader.readLine());
				
				adminService.updateHotelAvgRatePerNight(hotelId, avgRatePerNight);
				
			
				break;

			case "5":

				System.out.println("ENTER NEW HOTEL PHONE NO 1 :");
				phoneNo1=reader.readLine();
				
				adminService.updateHotelPhoneNo1(hotelId, phoneNo1);
				
				
				break;

			case "6":

				System.out.println("ENTER NEW HOTEL PHONE NO 2 :");
				phoneNo2=reader.readLine();
				
				adminService.updateHotelPhoneNo2(hotelId, phoneNo2);
				
				
				break;

			case "7":

				System.out.println("ENTER NEW HOTEL RATING :");
				rating=Integer.parseInt(reader.readLine());
				
				adminService.updateHotelRating(hotelId, rating);
				
			
				break;

			case "8":

				System.out.println("ENTER NEW HOTEL EMAIL ID :");
				email=reader.readLine();
			
				adminService.updateHotelEmail(hotelId, email);
				
			
				break;

			case "9":

				System.out.println("ENTER NEW HOTEL FAX NO :");
				fax=reader.readLine();
				
				adminService.updateHotelFax(hotelId, fax);
				
			
				break;
			case "10":
				performHotelManagment();
				break;

			default:
				System.err.println("Please enter valid option");
				updateHotelDetails(hotelId);
				break;
			}

		}
		catch (Exception e) 
		{
			// TODO: handle exception
		}
		}
	}

}
