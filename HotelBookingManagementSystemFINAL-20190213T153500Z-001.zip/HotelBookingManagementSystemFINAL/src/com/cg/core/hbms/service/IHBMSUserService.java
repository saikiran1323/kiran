package com.cg.core.hbms.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.cg.core.hbms.bean.Booking;
import com.cg.core.hbms.bean.Hotel;
import com.cg.core.hbms.bean.Login;
import com.cg.core.hbms.bean.Room;
import com.cg.core.hbms.bean.User;
import com.cg.core.hbms.exception.HBMSException;

public interface IHBMSUserService 
{

	public int addUser(User user,Login login) throws HBMSException;
	
	
	//customerMethods
	
	
	HashMap<Integer,Room> serachHotelRoomByHotelId(int hotelId)throws HBMSException;
	
	void bookHotelRooms(User user, HashMap<Integer, Integer> roomNoList, Booking booking)throws HBMSException;
	
	ArrayList viewBookingStatus(int bookingId)throws HBMSException;
	
	HashMap<Integer, Integer> getRoomDetails(int roomNo)throws HBMSException;
	
	String getHotelNameById(int hotelId)throws HBMSException;
	
	HashMap<Integer,Hotel>  showHotels()throws HBMSException;
	
	
	boolean isValidUser(int userId) throws HBMSException;

	
	double getBookingAmount(ArrayList<Integer> bookRooms) throws HBMSException;


	public void addBookingDetails(int userId,ArrayList<Integer> bookRooms, Booking booking ,double finalBookingAmount)throws HBMSException;


	
	
	
}
