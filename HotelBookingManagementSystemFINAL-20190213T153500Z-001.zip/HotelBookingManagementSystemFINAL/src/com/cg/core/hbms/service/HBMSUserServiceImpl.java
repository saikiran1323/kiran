package com.cg.core.hbms.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.cg.core.hbms.bean.Booking;
import com.cg.core.hbms.bean.Hotel;
import com.cg.core.hbms.bean.Login;
import com.cg.core.hbms.bean.Room;
import com.cg.core.hbms.bean.User;
import com.cg.core.hbms.dao.HBMSUserDaoImpl;
import com.cg.core.hbms.dao.IHBMSUserDao;
import com.cg.core.hbms.exception.HBMSException;

public class HBMSUserServiceImpl implements IHBMSUserService
{

	IHBMSUserDao userDao = new HBMSUserDaoImpl();

	@Override
	public int addUser(User user, Login login) throws HBMSException {
		// TODO Auto-generated method stub
		
		return userDao.addUser(user, login);
		
	}

	@Override
	public HashMap<Integer,Room> serachHotelRoomByHotelId(int hotelId)
			throws HBMSException {
		// TODO Auto-generated method stub
		return userDao.serachHotelRoomByHotelId(hotelId);
	}

	@Override
	public void bookHotelRooms(User user, HashMap<Integer, Integer> roomNoList,
			Booking booking) throws HBMSException {
		userDao.bookHotelRooms(user, roomNoList, booking);
		
	}

	@Override
	public ArrayList viewBookingStatus(int bookingId) throws HBMSException {
		// TODO Auto-generated method stub
		return userDao.viewBookingStatus(bookingId);
	}

	@Override
	public HashMap<Integer, Integer> getRoomDetails(int roomNo)
			throws HBMSException {
		
		return userDao.getRoomDetails(roomNo);
	}

	@Override
	public HashMap<Integer, Hotel> showHotels() throws HBMSException {
		// TODO Auto-generated method stub
		return userDao.showHotels();
	}

	@Override
	public String getHotelNameById(int hotelId) throws HBMSException {
		// TODO Auto-generated method stub
		return userDao.getHotelNameById(hotelId);
	}

	@Override
	public boolean isValidUser(int userId) throws HBMSException {
		// TODO Auto-generated method stub
		return userDao.isValidUser(userId);
	}

	@Override
	public double getBookingAmount(ArrayList<Integer> bookRooms)
			throws HBMSException {
		// TODO Auto-generated method stub
		return userDao.getBookingAmount(bookRooms);
	}

	@Override
	public void addBookingDetails(int userId, ArrayList<Integer> bookRooms,
			Booking booking, double finalBookingAmount) throws HBMSException
	{
		userDao.addBookingDetails(userId, bookRooms, booking, finalBookingAmount);
		
	}

	

	
}
