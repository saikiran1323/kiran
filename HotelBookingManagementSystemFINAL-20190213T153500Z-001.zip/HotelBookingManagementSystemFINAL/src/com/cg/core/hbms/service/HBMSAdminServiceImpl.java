package com.cg.core.hbms.service;

import java.time.LocalDate;
import java.util.HashMap;

import com.cg.core.hbms.bean.Booking;
import com.cg.core.hbms.bean.Hotel;
import com.cg.core.hbms.bean.Room;
import com.cg.core.hbms.bean.User;
import com.cg.core.hbms.dao.HBMSAdminDaoImpl;
import com.cg.core.hbms.dao.IHBMSAdminDao;
import com.cg.core.hbms.exception.HBMSException;

public class HBMSAdminServiceImpl implements IHBMSAdminService
{


	IHBMSAdminDao  adminDao = new HBMSAdminDaoImpl();
	

	@Override
	public String getRole(String username, String password)
			throws HBMSException {
		// TODO Auto-generated method stub
		return adminDao.getRole(username, password);
	}


	@Override
	public int addHotel(Hotel hotel) throws HBMSException {
		// TODO Auto-generated method stub
		return adminDao.addHotel(hotel);
	}


	@Override
	public void deleteHotel(int hotelId) throws HBMSException {
		adminDao.deleteHotel(hotelId);
		
	}
	
	@Override
	public void updateHotelName(int hotelId, String hotelName)
			throws HBMSException {
		adminDao.updateHotelName(hotelId, hotelName);
	}

	@Override
	public void updateHotelAddress(int hotelId, String address)
			throws HBMSException {
		adminDao.updateHotelAddress(hotelId, address);
		
	}

	@Override
	public void updateHotelDescription(int hotelId, String description)
			throws HBMSException {
		adminDao.updateHotelDescription(hotelId, description);
		
	}

	@Override
	public void updateHotelAvgRatePerNight(int hotelId, float avgRatePerNight)
			throws HBMSException {
		adminDao.updateHotelAvgRatePerNight(hotelId, avgRatePerNight);
		
	}

	@Override
	public void updateHotelPhoneNo1(int hotelId, String phoneNo1)
			throws HBMSException {
		adminDao.updateHotelPhoneNo1(hotelId, phoneNo1);
	}

	@Override
	public void updateHotelPhoneNo2(int hotelId, String phoneNo2)
			throws HBMSException {
		adminDao.updateHotelPhoneNo2(hotelId, phoneNo2);
	}

	@Override
	public void updateHotelEmail(int hotelId, String email)
			throws HBMSException {
		adminDao.updateHotelEmail(hotelId, email);
	}

	@Override
	public void updateHotelFax(int hotelId, String fax) throws HBMSException {
		adminDao.updateHotelFax(hotelId, fax);
	}

	@Override
	public void updateHotelRating(int hotelId, int rating) throws HBMSException {
		adminDao.updateHotelRating(hotelId, rating);
	}


	@Override
	public HashMap<Integer, Hotel> showAllHotels() throws HBMSException {
		// TODO Auto-generated method stub
		return adminDao.showAllHotels();
	}


	@Override
	public HashMap<Integer, Booking>  getBookingByDate(LocalDate date) throws HBMSException {
		// TODO Auto-generated method stub
		return adminDao.getBookingByDate(date);
	}


	@Override
	public HashMap<Integer, User> getUserList(int hotelId) throws HBMSException {
		// TODO Auto-generated method stub
		return adminDao.getUserList(hotelId);
	}


	@Override
	public int addRoom(Room room, int hotelId) throws HBMSException {
		return adminDao.addRoom(room, hotelId);
	}


	@Override
	public void deleteRoom(int roomId) throws HBMSException {
		adminDao.deleteRoom(roomId);
		
	}


	@Override
	public void updateRoomNo(int roomId, int roomNo)
			throws HBMSException {
		adminDao.updateRoomNo( roomId, roomNo);
	}


	@Override
	public void updateRoomType(int roomId, String roomType)
			throws HBMSException {
		adminDao.updateRoomType(roomId, roomType);
		
	}


	@Override
	public void updateRoomPerNightRate(int roomId,
			float perNightRate) throws HBMSException {
		adminDao.updateRoomPerNightRate(roomId, perNightRate);
		
	}


	@Override
	public void updateRoomAvailability(int hotelId, int roomId, int isAvailable)
			throws HBMSException {
		adminDao.updateRoomAvailability(hotelId, roomId, isAvailable);
		
	}


	@Override
	public HashMap<Integer, Booking> getHotelBooking(int hotelId)
			throws HBMSException {
		// TODO Auto-generated method stub
		return adminDao.getHotelBooking(hotelId);
	}


	

}
