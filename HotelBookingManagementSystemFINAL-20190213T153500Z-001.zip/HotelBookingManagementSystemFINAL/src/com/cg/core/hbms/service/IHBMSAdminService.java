package com.cg.core.hbms.service;

import java.time.LocalDate;
import java.util.HashMap;

import com.cg.core.hbms.bean.Booking;
import com.cg.core.hbms.bean.Hotel;
import com.cg.core.hbms.bean.Room;
import com.cg.core.hbms.bean.User;
import com.cg.core.hbms.exception.HBMSException;

public interface IHBMSAdminService
{

	//login with specified role
	
	String getRole(String username,String password)throws HBMSException;
	//add
	public int addHotel(Hotel hotel) throws HBMSException ;
	//delete
	public void deleteHotel(int hotelId) throws HBMSException ;
	
	//update
	
	public void updateHotelName(int hotelId,String hotelName) throws HBMSException;
	public void updateHotelAddress(int hotelId,String address) throws HBMSException;
	public void updateHotelDescription(int hotelId,String description) throws HBMSException;
	public void updateHotelAvgRatePerNight(int hotelId,float avgRatePerNight) throws HBMSException;
	public void updateHotelPhoneNo1(int hotelId,String phoneNo1) throws HBMSException;
	public void updateHotelPhoneNo2(int hotelId,String phoneNo2) throws HBMSException;
	public void updateHotelEmail(int hotelId,String email) throws HBMSException;
	public void updateHotelFax(int hotelId,String fax) throws HBMSException;
	public void updateHotelRating(int hotelId,int rating) throws HBMSException;
	
	//report generation methods
	HashMap<Integer,Hotel>  showAllHotels()throws HBMSException;
	public HashMap<Integer, Booking>  getBookingByDate(LocalDate date) throws HBMSException;
	public HashMap<Integer, User>  getUserList(int hotelId)  throws HBMSException;

	// add room
	public int addRoom(Room room, int hotelId) throws HBMSException;

	// delete room
	public void deleteRoom(int roomId) throws HBMSException;
	
	//Update Room Details
			public void updateRoomNo(int roomId,int roomNo) throws HBMSException;
			public void updateRoomType(int roomId,String roomType) throws HBMSException;
			public void updateRoomPerNightRate(int roomId,float perNightRate) throws HBMSException;
			public void updateRoomAvailability(int hotelId,int roomId,int isAvailable) throws HBMSException;
			public HashMap<Integer, Booking> getHotelBooking(int hotelId)throws HBMSException;
}
