package com.cg.core.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import com.cg.core.hbms.bean.Booking;
import com.cg.core.hbms.bean.Hotel;
import com.cg.core.hbms.bean.Login;
import com.cg.core.hbms.bean.Room;
import com.cg.core.hbms.bean.User;
import com.cg.core.hbms.exception.HBMSException;
import com.cg.core.hbms.util.DBUtil;

public class HBMSUserDaoImpl implements IHBMSUserDao
{
	
	Connection con ;
	public HBMSUserDaoImpl()
	{
		con = DBUtil.getConnection();
	}

	
	@Override
	public int addUser(User user, Login login) throws HBMSException {
		// TODO Auto-generated method stub
		if(true)
		{
			addUserdetails(user);
			addUserLoginDetails(login);
			return getUserId();

		}
		
		return 0;
	}
	
	private int addUserdetails(User user) throws HBMSException{
		// TODO Auto-generated method stub
		int userId=0;
		try
		{
			int row =0;
			String sql="INSERT INTO Users VALUES(user_id_seq.nextval,?,?,?,?,?,?,?)";
			PreparedStatement pstm =  con.prepareStatement(sql);
			
			pstm.setString(1,user.getFirstName());
			pstm.setString(2,user.getLastName() );
			pstm.setString(3,user.getUsername());
			pstm.setString(4,user.getMobileNo());
			pstm.setString(5,user.getPhoneNo());
			pstm.setString(6,user.getAddress());
			pstm.setString(7,user.getEmail());
			
		    row = pstm.executeUpdate();
		    
		    
		    userId=getUserId();
		       
		    
		}catch (Exception e) {
			// TODO Auto-generated catch block
			throw new HBMSException(e.getMessage());
		}
		return userId;
	
	}
	private boolean addUserLoginDetails(Login login) throws HBMSException{
		// TODO Auto-generated method stub
		try
		{
			int row =0;
			String sql="INSERT INTO login VALUES(login_id_seq.nextval,?,?,?)";
			PreparedStatement pstm =  con.prepareStatement(sql);
			
			pstm.setString(1,login.getUsername());
			pstm.setString(2,login.getPassword() );
			pstm.setString(3,login.getRole());
		
		    row = pstm.executeUpdate();
		    
		}catch (Exception e) {
			// TODO Auto-generated catch block
			throw new HBMSException(e.getMessage());
		}
		return true;
	}
	
	
	public int getUserId()
	{
		String sql="SELECT user_id_seq.currval FROM DUAL";
		int userId = 0;
		
		try 
		{
			Statement stmt = con.createStatement();
			
			ResultSet result =stmt.executeQuery(sql);
			
			if(result.next())
			{
				userId=result.getInt(1);
			}
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return userId;
	}
	
	//customer methods
	
	
	@Override
	public HashMap<Integer,Room> serachHotelRoomByHotelId(int hotelId) throws HBMSException 
	{
		HashMap<Integer,Room> roomList = new HashMap<Integer,Room>();
		
		String sql="SELECT room_id,room_no,room_type,per_night_rate,availability FROM RoomDetails WHERE hotel_id = ? AND availability='1'";
		
		try
		{
			
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1,hotelId);
			ResultSet result=pst.executeQuery();
			
			while(result.next())
			{
				Room room = new Room();
				
				room.setRoomId(result.getInt("room_id"));
				room.setRoomNo(result.getInt("room_no"));
				room.setRoomType(result.getString("room_type"));
				room.setPerNightRate(result.getFloat("per_night_rate"));
				room.setAvailable(result.getInt("availability"));
				roomList.put(room.getRoomId(),room);
				
			}
		} 
		catch (SQLException e)
		{
			throw new HBMSException("Unable to serach Rooms for Hotel Id"+ hotelId );
			
		}
		return roomList;
	}

	

	@Override
	public ArrayList viewBookingStatus(int bookingId)throws HBMSException 
	{
		Booking booking = new Booking();
		
		
		ArrayList bookingStatus = new ArrayList();
		
		String sql="SELECT booking_id ,booked_from ,booked_to,no_of_adults ,no_of_childern ,amount FROM BookingDetails WHERE booking_id = ?";
		
		try 
		{
			PreparedStatement pst= con.prepareStatement(sql);
			pst.setInt(1,bookingId);
			ResultSet result = pst.executeQuery();
		
			while(result.next())
			{			
				int id=result.getInt("booking_id");
				//int roomNo=result.getInt("room_no");
				//String roomType=result.getString("roomType");
				LocalDate bookedForm=result.getDate("booked_from").toLocalDate();
				LocalDate bookedTo=result.getDate("booked_to").toLocalDate();
				int adults=result.getInt("no_of_adults");
				int childeren=result.getInt("no_of_childern");
				Double amount=result.getDouble("amount");
				
				bookingStatus.add(id);
				bookingStatus.add(bookedForm);
				bookingStatus.add(bookedTo);
				bookingStatus.add(adults);
				bookingStatus.add(childeren);
				bookingStatus.add(amount);
	
			}
			
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			throw new HBMSException("Cannot find the details of booking Id "+bookingId);
		}
		
		
		return bookingStatus;
	}

	@Override
	public HashMap<Integer,Hotel> showHotels()throws HBMSException
	{
		HashMap<Integer, Hotel> hotels = new HashMap<Integer, Hotel>();;
		String sql="SELECT hotel_id,hotel_name,address,description,avg_rate_per_night,phone_no1,phone_no2,rating,email FROM Hotel";
		
		try
		{
			Statement stmt = con.createStatement();
			ResultSet result = stmt.executeQuery(sql);
			
			while(result.next())
			{
			 
				Hotel hotel = new Hotel();
				
				hotel.setHotelId(result.getInt("hotel_id"));
				hotel.setHotelName(result.getString("hotel_name"));
				hotel.setAddress(result.getString("address"));
				hotel.setDescription(result.getString("description"));
				hotel.setAvgRatePerNight(result.getFloat("avg_rate_per_night"));
				hotel.setPhoneNo1(result.getString("phone_no1"));
				hotel.setPhoneNo2(result.getString("phone_no2"));
				hotel.setRating(result.getInt("rating"));
				hotel.setEmail(result.getString("email"));
				
				hotels.put(hotel.getHotelId(), hotel);
			}
		} 
		catch (SQLException e)
		{
			throw new HBMSException("Failed To Display Catelog");
		}
		
		return hotels;
		
		
		
	}


	@Override
	public void bookHotelRooms(User user, HashMap<Integer,Integer> roomNoList,Booking booking)throws HBMSException
	{
		String sql="INSERT INTO Users VALUES(user_id_seq .nextval,?,?,?,?,?,?)";
		String sql1="";
		String sql3="INSERT INTO BookingDetails(booking_id_seq.nextval,?,?,?,?,?)";
		
		Set<Integer> keys = roomNoList.keySet();
		
		for (Integer key : keys) 
		{
			Integer value = roomNoList.get(key);
			
			System.out.println(value);
		}
		
		try
		{
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setString(1,user.getFirstName());
			pst.setString(2,user.getLastName());
			pst.setString(3,user.getMobileNo());
			pst.setString(4,user.getPhoneNo());
			pst.setString(5,user.getAddress());
			pst.setString(6,user.getEmail());
			
			int row=pst.executeUpdate();
			
			if(row==1)
			{
				System.out.println("UserDetails Inserted");
			}
		} 
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
		//	e.printStackTrace();
			
			throw new HBMSException("Failed to add new User Details");
		}
		
		try 
		{
			PreparedStatement pst = con.prepareStatement(sql3);
			
		//	pst.setInt(1,);
			//pst.setInt(2,);
			pst.setDate(1,java.sql.Date.valueOf(booking.getBookedFrom()));
			pst.setDate(2,java.sql.Date.valueOf(booking.getBookedTo()));
			pst.setInt(3,booking.getNoOfAdults());
			pst.setInt(4, booking.getNoOfchildren());
			pst.setDouble(5, booking.getAmount());
			
			int row=pst.executeUpdate();
			
			if(row==1)
			{
				System.out.println("Booking details inserted ");
			}
		}
		catch (Exception e)
		{
			throw new HBMSException("Failed to add new booking Details");
		}
		
	}



	@Override
	public HashMap<Integer, Integer> getRoomDetails(int roomNo)throws HBMSException
	{
		HashMap<Integer, Integer> list= new HashMap<Integer, Integer>();
		
		String sql="SELECT room_id,hotel_id FROM RoomDetails WHERE room_no = ?";
		
		try
		{
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setInt(1,roomNo);
			
			ResultSet result =pst.executeQuery();
			
			while(result.next())
			{
				list.put(result.getInt("hotel_id"),result.getInt("room_id"));
			}
		} 
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return list;
	}


	@Override
	public String getHotelNameById(int hotelId) throws HBMSException
	{
		
		String sql="SELECT hotel_name FROM Hotel WHERE hotel_id = ?";
		String hotelName = null;
		try
		{
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1,hotelId);
			ResultSet result = pst.executeQuery();
			
			if(result.next())
			{
	
				hotelName=result.getString(1);
			}
			
		} 
		catch (SQLException e)
		{
			throw new HBMSException("Hotel Name not Found For Hotel ID:"+hotelId);
		}
		return hotelName;
	}


	@Override
	public boolean isValidUser(int userId) throws HBMSException
	{
		String sql="SELECT * FROM Users WHERE user_id = ?";
		boolean flag=false;
		try 
		{
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setInt(1, userId);
			ResultSet result = pst.executeQuery();
			
			if(result.next())
			{
				flag=true;
			}
			else
			{
				throw new HBMSException("CANNOT FIND USER WITH USER ID:"+userId);
			}
		}
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return flag;
	}


	@Override
	public double getBookingAmount(ArrayList<Integer> roomId) throws HBMSException
	{
		double amount = 0;
		if(roomId.size()!=0)
		{
			String sql="select per_night_rate from roomDetails where room_id in(?)";
		
			try
			{
				PreparedStatement pst = con.prepareStatement(sql);
				
				for (int i = 0; i < roomId.size(); i++)
				{
					pst.setInt(1,roomId.get(i));
					
					ResultSet result=pst.executeQuery();
					
					if(result.next())
					{
						amount=amount+result.getDouble(1);
						
						getRoomId(roomId.get(i));
					}
					
				}
				
				
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
				
		return amount;
	}


	private void getRoomId(Integer integer)
	{
		// TODO Auto-generated method stub
		
		String sql="SELECT room_id from RoomDetails WHERE room_no = ?";
		
		ArrayList<Integer> roomId = new ArrayList<Integer>();
		
		
		try 
		{
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setInt(1, integer);
			
			ResultSet result = pst.executeQuery();
			
			if(result.next())
			{
				roomId.add(result.getInt(1));
			}
			
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}


	@Override
	public void addBookingDetails(int userId,ArrayList<Integer> roomId, Booking booking,double finalBookingAmount) throws HBMSException
	{
		
		String sql="INSERT INTO BookingDetails VALUES(booking_id_seq.nextval,?,?,?,?,?,?)";
		int bookingId=0;
		
		
		
		try
		{
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setInt(1,userId);
			//pst.setInt(2, 101);
			pst.setDate(2,java.sql.Date.valueOf(booking.getBookedFrom()));
			pst.setDate(3,java.sql.Date.valueOf(booking.getBookedTo()));
			pst.setInt(4, booking.getNoOfAdults());
			pst.setInt(5, booking.getNoOfchildren());
			pst.setDouble(6,finalBookingAmount);
			
			int row =pst.executeUpdate();
			if(row==1)
			{
				addRoomBookingDetails(roomId);
				bookingId=getBookingId();
				System.out.println("BOOKING DETAILS INSERTED SUCCESSFULLY WITH BOOKING ID :"+bookingId);
				
				
			}
		}
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	
	
	private void addRoomBookingDetails(ArrayList<Integer> roomId) 
	{
		String sql="INSERT INTO bookingRoomdetails VALUES(?,?)";
		int bookingId=getBookingId();
		if(roomId.size()!=0)
		{
		try
		{
			PreparedStatement pst =con.prepareStatement(sql);
			for (int i = 0; i < roomId.size(); i++) 
			{
				pst.setInt(1, bookingId);
				pst.setInt(2, roomId.get(i));
				
				int row=pst.executeUpdate();
				
				if(row==1)
				{
					setAvailability(roomId.get(i));
					System.out.println("Updated");
					
				}
				
			}
			
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		else
		{
			try
			{
				throw new HBMSException("SOMETHING WNT WRONG");
			} 
			catch (HBMSException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
					
	}


	public void setAvailability(int roomId)
	{
			
		
			String sql ="UPDATE RoomDetails SET availability ='0' WHERE room_id in (?)";


			try
			{
				PreparedStatement pst = con.prepareStatement(sql);
				
				pst.setInt(1,roomId);
					
					pst.executeUpdate();
				
				
				
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


			
		}
		
	
	
	
	public int getBookingId()
	{
		String sql="SELECT booking_id_seq.currval FROM DUAL";
		int bookingId = 0;
		
		try 
		{
			Statement stmt = con.createStatement();
			
			ResultSet result =stmt.executeQuery(sql);
			
			if(result.next())
			{
				bookingId=result.getInt(1);
			}
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return bookingId;
	}

}
