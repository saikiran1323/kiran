package com.cg.core.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.cg.core.hbms.bean.Booking;
import com.cg.core.hbms.bean.Hotel;
import com.cg.core.hbms.bean.Room;
import com.cg.core.hbms.bean.User;
import com.cg.core.hbms.exception.HBMSException;
import com.cg.core.hbms.logger.HBMSLogger;
import com.cg.core.hbms.util.DBUtil;

public class HBMSAdminDaoImpl implements IHBMSAdminDao
{
	public Logger log = HBMSLogger.getLog();
	
	HBMSLogger logger = new HBMSLogger();
	
	
	Connection con ;
	public HBMSAdminDaoImpl()
	{
		con = DBUtil.getConnection();
		
		if(con!=null)
			log.info("Obtained Connection");
	}


	@Override
	public String getRole(String username, String password)
			throws HBMSException 
	{
		String sql="SELECT role from Login WHERE username = ? AND password = ?";
		String role="";
		try 
		{
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1,username);
			pst.setString(2, password);
			
			ResultSet result = pst.executeQuery();
			
			while(result.next())
			{
				role=result.getString("role");
				log.info(role);
			}
		} 
		catch (SQLException e) 
		{
		
			log.error(e.getMessage());
			throw new HBMSException("Incorrect Username or Password");
			
		}
		
		return role;
	}


	@Override
	public int addHotel(Hotel hotel) throws HBMSException 
	{

		int hotelId;
		try
		{
			int row =0;
			
			String sql="INSERT INTO Hotel VALUES(hotel_id_seq.nextval,?,?,?,?,?,?,?,?,?)";
		
			PreparedStatement pstm =  con.prepareStatement(sql);
			
			pstm.setString(1,hotel.getHotelName());
			pstm.setString(2,hotel.getAddress() );
			pstm.setString(3,hotel.getDescription() );
			pstm.setFloat(4,hotel.getAvgRatePerNight() );
			pstm.setString(5,hotel.getPhoneNo1() );
			pstm.setString(6,hotel.getPhoneNo2() );
			pstm.setDouble(7,hotel.getRating());
			pstm.setString(8,hotel.getEmail());
			pstm.setString(9,hotel.getFax() );
			hotelId=hotel.getHotelId();
		    row = pstm.executeUpdate();	
		    if(row>0)
		    {
		    	hotelId=getHotelId();
		    }
		    
		}
		catch (Exception e)
		{
			
			log.error(e.getMessage());	
			throw new HBMSException(e.getMessage());
		}
		return hotelId;
	}

	public int getHotelId()
	{
		int hotelId=0;
		String sql = "SELECT hotel_id_seq.currval from DUAL";
		
		try {
			Statement stmt = con.createStatement();
			ResultSet result = stmt.executeQuery(sql);
			if(result.next())
			{
				hotelId= result.getInt(1);
			}
		} catch (SQLException e)
		{
			log.error(e.getMessage());
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		return hotelId;
	}

	@Override
	public void deleteHotel(int hotelId) throws HBMSException 
	{
		try
		{
//			if(getHotelById(id)== null)      //getHotelById method 
//			{
//				throw new ProductException("Hotel does Not exist : cannot be delete");
//			}
			PreparedStatement pstm = con.prepareStatement("DELETE FROM Hotel where hotel_id=?");
			pstm.setInt(1, hotelId);
			pstm.execute();
			
			System.out.println("Hotel ID "+hotelId+" Deleted Successfully ");
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			throw new HBMSException(e.getMessage());
		}
		
	}
	
	
	@Override
	public void updateHotelName(int hotelId,String hotelName) throws HBMSException {
		String sql="UPDATE Hotel SET hotel_Name=? where hotel_Id=?";
		try
		{
			int row;
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setString(1,hotelName);
			pst.setInt(2,hotelId);

		    row=pst.executeUpdate();
			if(row==1)
			{
				System.out.println("HOTEL NAME UPDATED SUCCESSFULLY");
			}
		} 
		catch (SQLException e)
		{
			throw new HBMSException("Failed to Update Hotel Name");
		}
		
	}

	@Override
	public void updateHotelAddress(int hotelId, String address)
			throws HBMSException {
		String sql="UPDATE Hotel SET address=? where hotel_Id=?";
		try
		{
			int row;
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setString(1,address);
			pst.setInt(2,hotelId);

		    row=pst.executeUpdate();
			if(row==1)
			{
				System.out.println("HOTEL ADDRESS UPDATED SUCCESSFULLY");
			}
		} 
		catch (SQLException e)
		{
			throw new HBMSException("Failed to Update Hotel Address");
		}
		
	}

	@Override
	public void updateHotelDescription(int hotelId, String description)
			throws HBMSException {
		String sql="UPDATE Hotel SET description=? where hotel_Id=?";
		try
		{
			int row;
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setString(1,description);
			pst.setInt(2,hotelId);

		    row=pst.executeUpdate();
			if(row==1)
			{
				System.out.println("HOTEL DESCRIPTION UPDATED SUCCESSFULLY");
			}
		} 
		catch (SQLException e)
		{
			throw new HBMSException("Failed to Update Hotel Description");
		}
	}

	@Override
	public void updateHotelAvgRatePerNight(int hotelId, float avgRatePerNight)
			throws HBMSException {
		String sql="UPDATE Hotel SET avg_rate_per_night=? where hotel_Id=?";
		try
		{
			int row;
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setFloat(1,avgRatePerNight);
			pst.setInt(2,hotelId);

		    row=pst.executeUpdate();
			if(row==1)
			{
				System.out.println("HOTEL AVERAGE RATE PER NIGHT UPDATED SUCCESSFULLY");
			}
		} 
		catch (SQLException e)
		{
			throw new HBMSException("Failed to Update Average Rate Per Night");
		}
	}

	@Override
	public void updateHotelPhoneNo1(int hotelId, String phoneNo1)
			throws HBMSException {
		String sql="UPDATE Hotel SET phone_no1=? where hotel_Id=?";
		try
		{
			int row;
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setString(1,phoneNo1);
			pst.setInt(2,hotelId);

		    row=pst.executeUpdate();
			if(row==1)
			{
				System.out.println("HOTEL PHONE NO 1 UPDATED SUCCESSFULLY");
			}
		} 
		catch (SQLException e)
		{
			throw new HBMSException("Failed to Update PhoneNo1");
		}
	}

	@Override
	public void updateHotelPhoneNo2(int hotelId, String phoneNo2)
			throws HBMSException {
		String sql="UPDATE Hotel SET phone_no2=? where hotel_Id=?";
		try
		{
			int row;
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setString(1,phoneNo2);
			pst.setInt(2,hotelId);

		    row=pst.executeUpdate();
			if(row==1)
			{
				System.out.println("HOTEL PHONE NO 2 UPDATED SUCCESSFULLY");
			}
		} 
		catch (SQLException e)
		{
			throw new HBMSException("Failed to Update PhoneNo2");
		}
	}

	@Override
	public void updateHotelEmail(int hotelId, String email)
			throws HBMSException {
		String sql="UPDATE Hotel SET email=? where hotel_Id=?";
		try
		{
			int row;
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setString(1,email);
			pst.setInt(2,hotelId);

		    row=pst.executeUpdate();
			if(row==1)
			{
				System.out.println("HOTEL EMAIL ID UPDATED SUCCESSFULLY");
			}
		} 
		catch (SQLException e)
		{
			throw new HBMSException("Failed to Update Email");
		}
	}

	@Override
	public void updateHotelFax(int hotelId, String fax) throws HBMSException {
		String sql="UPDATE Hotel SET fax=? where hotel_Id=?";
		try
		{
			int row;
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setString(1,fax);
			pst.setInt(2,hotelId);

		    row=pst.executeUpdate();
			if(row==1)
			{
				System.out.println("HOTEL FAX UPDATED SUCCESSFULLY");
			}
		} 
		catch (SQLException e)
		{
			throw new HBMSException("Failed to Update Fax");
		}
	}

	@Override
	public void updateHotelRating(int hotelId, int rating) throws HBMSException {
		String sql="UPDATE Hotel SET rating=? where hotel_Id=?";
		try
		{
			int row;
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setInt(1,rating);
			pst.setInt(2,hotelId);

		    row=pst.executeUpdate();
			if(row==1)
			{
				System.out.println("HOTEL RATING UPDATED SUCCESSFULLY");
			}
		} 
		catch (SQLException e)
		{
			throw new HBMSException("Failed to Update Rating");
		}
	}



	@Override
	public HashMap<Integer,Hotel> showAllHotels()throws HBMSException
	{
		HashMap<Integer, Hotel> hotels = new HashMap<Integer, Hotel>();;
		String sql="SELECT hotel_id,hotel_name,address,description,avg_rate_per_night,phone_no1,phone_no2,rating,email FROM Hotel";
		
		try
		{
			Statement stmt = con.createStatement();
			ResultSet result = stmt.executeQuery(sql);
			
			while(result.next())
			{
			 
				Hotel hotel = new Hotel();
				
				hotel.setHotelId(result.getInt("hotel_id"));
				hotel.setHotelName(result.getString("hotel_name"));
				hotel.setAddress(result.getString("address"));
				hotel.setDescription(result.getString("description"));
				hotel.setAvgRatePerNight(result.getFloat("avg_rate_per_night"));
				hotel.setPhoneNo1(result.getString("phone_no1"));
				hotel.setPhoneNo2(result.getString("phone_no2"));
				hotel.setRating(result.getInt("rating"));
				hotel.setEmail(result.getString("email"));
				
				hotels.put(hotel.getHotelId(), hotel);
			}
		} 
		catch (SQLException e)
		{
			throw new HBMSException("Failed To Display Catelog");
		}
		
		return hotels;
		
		
		
	}
	
	
	@Override
	public HashMap<Integer, Booking> getBookingByDate(LocalDate date) throws HBMSException {
		// TODO Auto-generated method stub
		HashMap<Integer, Booking> bookingMap = new HashMap<Integer, Booking>();
		
		try
		{
			String sql="select * from bookingdetails where ? between booked_from AND booked_to";
			PreparedStatement pstm= con.prepareStatement(sql);
			pstm.setDate(1, java.sql.Date.valueOf(date));
			
			
			ResultSet result=pstm.executeQuery();
			if(result.next()){
				Booking booking = new Booking();
				booking.setBookingId(result.getInt("user_id")); 
				booking.setBookedFrom(result.getDate("booked_from").toLocalDate());
				booking.setBookedTo(result.getDate("booked_to").toLocalDate());
				booking.setNoOfAdults(result.getInt("no_of_adults"));
				booking.setNoOfchildren(result.getInt("no_of_children"));
				booking.setAmount(result.getDouble("amount"));
				
				bookingMap.put(booking.getBookingId(), booking);
				
			}
			
	}catch (Exception e) {
		// TODO Auto-generated catch block
		throw new HBMSException(e.getMessage());
	}
		return bookingMap;
	}
	
	@Override
	public HashMap<Integer, User>  getUserList(int hotelId) throws HBMSException {
		// TODO Auto-generated method stub
		HashMap<Integer, User> guestList = new HashMap<Integer, User>();
		
		String sql="select * FROM Roomdetails r,bookingdetails b,users u where b.room_id = r.room_id AND u.user_id = b.user_id AND hotel_id=?";
	
			try
			{
			PreparedStatement pstm= con.prepareStatement(sql);
			pstm.setInt(1, hotelId);
		
			ResultSet result=pstm.executeQuery();
			
			if(result.next()){
				
				User user=new User();
				user.setUserId(result.getInt("user_Id"));
				user.setFirstName(result.getString("first_Name"));
				user.setLastName(result.getString("last_Name"));
				user.setUsername(result.getString("user_Name"));
				user.setMobileNo(result.getString("mobile_No"));
				user.setPhoneNo(result.getString("phone_No"));
				user.setAddress(result.getString("address"));
				user.setEmail(result.getString("emailId"));
				
				guestList.put(user.getUserId(), user);
				
				System.out.println(user);
			}
			
			}catch (Exception e) {
			// TODO Auto-generated catch block
			throw new HBMSException(e.getMessage());
	}
		return guestList;
		
		
	}


	@Override
	public int addRoom(Room room,int hotelId) throws HBMSException {
		// TODO Auto-generated method stub
		int roomId=0;
		try
		{
			int row =0;
			int availability=1;
			String sql="INSERT INTO RoomDetails VALUES(room_id_seq.nextval,?,?,?,?,?)";
			
			PreparedStatement pstm =  con.prepareStatement(sql);
			
			pstm.setInt(1,hotelId);
			pstm.setInt(2,room.getRoomNo() );
			pstm.setString(3,room.getRoomType() );
			pstm.setFloat(4,room.getPerNightRate() );
			pstm.setInt(5, availability);
		
		    row = pstm.executeUpdate();	
		    if(row>0)
		    {
		    	roomId=getRoomId();
		    }
		    
		}catch (Exception e) {
			e.printStackTrace();
			throw new HBMSException(e.getMessage());
		}
		return roomId;
	}
	private int getRoomId() {
		int roomId=0;
		String sql = "SELECT room_id_seq.currval from DUAL";
		
		try {
			Statement stmt = con.createStatement();
			ResultSet result = stmt.executeQuery(sql);
			if(result.next())
			{
				roomId= result.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		return roomId;
	}
	@Override
	public void deleteRoom(int roomId) throws HBMSException {
		// TODO Auto-generated method stub
		try
		{
			/*if(getRoomById(hotelId)== null)      //getRoomById method 
			{
				throw new HBMSException("Room does Not exist : cannot be delete");
			}*/
			PreparedStatement pstm = con.prepareStatement("DELETE FROM RoomDetails where ROOM_ID=?");
			pstm.setInt(1, roomId);
			pstm.execute();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			throw new HBMSException(e.getMessage());
		}
	}

	

	@Override
	public void updateRoomNo(int roomId, int roomNo)
			throws HBMSException {
		String sql="UPDATE RoomDetails SET room_no=? where room_id=?";
		try 
		{
			int row;
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setInt(1,roomNo);
			pst.setInt(2,roomId);
			
			row=pst.executeUpdate();
			if(row==1)
			{
				System.out.println("ROOM NO UPDATED SUCCESSFULLY");
			}
		}
		catch (Exception e) 
		{
			throw new HBMSException("Failed to Update Room Number!!!");
		}
		
	}

	@Override
	public void updateRoomType(int roomId, String roomType)
			throws HBMSException {
		String sql="UPDATE RoomDetails SET roomType=? where room_id=?";
		try 
		{
			int row;
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setString(1, roomType);
			pst.setInt(2, roomId);
			
			row=pst.executeUpdate();
			
			if(row==1)
			{
				System.out.println("ROOM TYPE UPDATED SUCCESSFULLY");
			}
		}
		catch (Exception e) 
		{
			throw new HBMSException("Failed to Update Room Type!!!");
		}
	}

	@Override
	public void updateRoomPerNightRate(int roomId,float perNightRate) throws HBMSException {
		String sql="UPDATE RoomDetails SET per_night_rate=? where room_id=?";
		try 
		{
			int row;
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setFloat(1, perNightRate);
			pst.setInt(2, roomId);
			
			row=pst.executeUpdate();
			if(row==1)
			{
				System.out.println("ROOM PER NIGHT RATE UPDATED SUCCESSFULLY");
			}
		}
		catch (Exception e) 
		{
			throw new HBMSException("Failed to Update Room PerNightRate!!!");
		}
	}

	@Override
	public void updateRoomAvailability(int hotelId, int roomId, int isAvailable)
			throws HBMSException {
		String sql="UPDATE RoomDetails SET availability=? where hotel_Id=? AND room_id=?";
		try 
		{
			int row;
			PreparedStatement pst = con.prepareStatement(sql);
			
			pst.setInt(1, isAvailable);
			pst.setInt(2, hotelId);
			pst.setInt(3, roomId);
			
			row=pst.executeUpdate();
			if(row==1)
			{
				System.out.println("Room Availability Updated Successfully!!!");
			}
		}
		catch (Exception e) 
		{
			throw new HBMSException("Failed to Update Room Availability!!!");
		}
	}
	@Override
	public HashMap<Integer, Booking> getHotelBooking(int hotelId)
			throws HBMSException {
		// TODO Auto-generated method stub
		String sql="SELECT b.booking_id,b.booked_from,b.booked_to,b.no_of_adults,no_of_children,b.amount FROM Roomdetails r,bookingdetails b WHERE b.room_id = r.room_id AND r.hotel_id=?";
		//String sql="select * from bookingdetails";
		HashMap<Integer, Booking> bookMap= new HashMap<Integer, Booking>();
		try
		{
			PreparedStatement pstm = con.prepareStatement(sql);
			pstm.setInt(1, hotelId);
			ResultSet result=pstm.executeQuery();
			
			while(result.next())
			{
				Booking booking = new Booking();
				booking.setBookingId(result.getInt("booking_id"));
				booking.setBookedFrom(result.getDate("booked_from").toLocalDate());
				booking.setBookedTo(result.getDate("booked_to").toLocalDate());
				booking.setNoOfAdults(result.getInt("no_of_adults"));
				booking.setNoOfchildren(result.getInt("no_of_children"));
				booking.setAmount(result.getDouble("amount"));
				
				bookMap.put(booking.getBookingId(), booking);
			}
			System.out.println(bookMap);
		}
		catch (Exception e) {
				// TODO Auto-generated catch block
		e.printStackTrace();
		}
		return bookMap;
	}

	
}
