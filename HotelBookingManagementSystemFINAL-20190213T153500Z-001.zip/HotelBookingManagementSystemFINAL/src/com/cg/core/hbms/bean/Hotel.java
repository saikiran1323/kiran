package com.cg.core.hbms.bean;

public class Hotel {

	private int hotelId;
	private String hotelName;
	private String address;
	private String description;
	private float avgRatePerNight;
	private String phoneNo1;
	private String phoneNo2;
	private String email;
	private String fax;
	private double rating;

	public Hotel() {
		super();
	}

	
	public Hotel(int hotelId, String hotelName, String address,
			String description, float avgRatePerNight, String phoneNo1,
			String phoneNo2, String email, String fax, double rating) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.address = address;
		this.description = description;
		this.avgRatePerNight = avgRatePerNight;
		this.phoneNo1 = phoneNo1;
		this.phoneNo2 = phoneNo2;
		this.email = email;
		this.fax = fax;
		this.rating = rating;
	}


	


	public Hotel(String hotelName, String address, String description,
			float avgRatePerNight, String phoneNo1, String phoneNo2,
			String email, String fax, int rating) {
		super();
		this.hotelName = hotelName;
		this.address = address;
		this.description = description;
		this.avgRatePerNight = avgRatePerNight;
		this.phoneNo1 = phoneNo1;
		this.phoneNo2 = phoneNo2;
		this.email = email;
		this.fax = fax;
		this.rating = rating;
	}


	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public float getAvgRatePerNight() {
		return avgRatePerNight;
	}

	public void setAvgRatePerNight(float avgRatePerNight) {
		this.avgRatePerNight = avgRatePerNight;
	}

	public String getPhoneNo1() {
		return phoneNo1;
	}

	public void setPhoneNo1(String phoneNo1) {
		this.phoneNo1 = phoneNo1;
	}

	public String getPhoneNo2() {
		return phoneNo2;
	}

	public void setPhoneNo2(String phoneNo2) {
		this.phoneNo2 = phoneNo2;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}


	@Override
	public String toString() {
		return "Hotel [hotelId=" + hotelId + ", hotelName=" + hotelName
				+ ", address=" + address + ", description=" + description
				+ ", avgRatePerNight=" + avgRatePerNight + ", phoneNo1="
				+ phoneNo1 + ", phoneNo2=" + phoneNo2 + ", email=" + email
				+ ", fax=" + fax + ", rating=" + rating + "]";
	}

	

}
