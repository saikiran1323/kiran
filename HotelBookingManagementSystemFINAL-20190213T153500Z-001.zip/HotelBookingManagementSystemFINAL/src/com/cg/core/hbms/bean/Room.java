package com.cg.core.hbms.bean;

public class Room {

	private int roomId;
	private int roomNo;
	private String roomType;
	private float perNightRate;
	private int isAvailable;

	public Room() {
		super();
	}

	

	public Room(int roomNo, String roomType, float perNightRate) {
		super();
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.perNightRate = perNightRate;
	}



	public Room(int roomId, int roomNo, String roomType, float perNightRate,
			int isAvailable) {
		super();
		this.roomId = roomId;
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.perNightRate = perNightRate;
		this.isAvailable = isAvailable;
	}



	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	public int getRoomNo() {
		return roomNo;
	}

	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public float getPerNightRate() {
		return perNightRate;
	}

	public void setPerNightRate(float perNightRate) {
		this.perNightRate = perNightRate;
	}

	public int isAvailable() {
		return isAvailable;
	}

	public void setAvailable(int isAvailable) {
		this.isAvailable = isAvailable;
	}



	@Override
	public String toString() {
		return "Room [roomId=" + roomId + ", roomNo=" + roomNo + ", roomType="
				+ roomType + ", perNightRate=" + perNightRate
				+ ", isAvailable=" + isAvailable + "]";
	}

	

}
