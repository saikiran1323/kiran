package com.cg.core.hbms.bean;

import java.time.LocalDate;

public class Booking
{

	private int bookingId;
	private LocalDate bookedFrom;
	private LocalDate bookedTo;
	private int noOfAdults;
	private int noOfchildren;
	private double amount;
	
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public LocalDate getBookedFrom() {
		return bookedFrom;
	}
	public void setBookedFrom(LocalDate bookedFrom) {
		this.bookedFrom = bookedFrom;
	}
	public LocalDate getBookedTo() {
		return bookedTo;
	}
	public void setBookedTo(LocalDate bookedTo) {
		this.bookedTo = bookedTo;
	}
	public int getNoOfAdults() {
		return noOfAdults;
	}
	public void setNoOfAdults(int noOfAdults) {
		this.noOfAdults = noOfAdults;
	}
	public int getNoOfchildren() {
		return noOfchildren;
	}
	public void setNoOfchildren(int noOfchildren) {
		this.noOfchildren = noOfchildren;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Booking() {
		super();
	}
	public Booking(LocalDate bookedFrom, LocalDate bookedTo, int noOfAdults,
			int noOfchildren, double amount) {
		super();
		this.bookedFrom = bookedFrom;
		this.bookedTo = bookedTo;
		this.noOfAdults = noOfAdults;
		this.noOfchildren = noOfchildren;
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Booking [bookedFrom=" + bookedFrom + ", bookedTo=" + bookedTo
				+ ", noOfAdults=" + noOfAdults + ", noOfchildren="
				+ noOfchildren + ", amount=" + amount + "]";
	}

	
	

	
	
}
