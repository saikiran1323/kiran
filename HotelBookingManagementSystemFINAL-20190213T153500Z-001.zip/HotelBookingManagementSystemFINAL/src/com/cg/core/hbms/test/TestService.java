//package com.cg.core.hbms.test;
//
//import java.time.LocalDate;
//import java.time.format.DateTimeFormatter;
//import java.util.HashMap;
//
//import com.cg.core.hbms.bean.Booking;
//import com.cg.core.hbms.bean.Hotel;
//import com.cg.core.hbms.bean.Login;
//import com.cg.core.hbms.bean.Room;
//import com.cg.core.hbms.exception.HBMSException;
//import com.cg.core.hbms.service.HBMSAdminServiceImpl;
//import com.cg.core.hbms.service.IHBMSAdminService;
//
//public class TestService {
//	public static void main(String[] args) {
//		IHBMSAdminService service = new HBMSAdminServiceImpl();
//		//Hotel hotel=new Hotel()
//		Hotel hotel=new Hotel("Taj","Mumbai","desc",1000,"889898989","45454545","email@email.com","89898",5);
//		Login login=new Login("rutu","pass123","customer");
//		//User user = new User("monika","kapopara","rutu","889843431","282828","mumbai","monika@email.com");
//		Room room = new Room(5555,"AC",555.5f);
//		try {
//			
//			//add Hotel
//			/*int hotelid=service.addHotel(hotel);
//			System.out.println("Successfully added"+hotelid);*/
//			
//			
//			/*service.deleteHotel(10003);
//			System.out.println("deleted sucessfully");*/
//			
//			
//			/*HashMap<Integer, Hotel> hotelmap = service.showAllHotels();
//			 System.out.println(Collections.singletonList(hotelmap));
//			service.addUser(user, login);
//			System.out.println("user added");*/
//			
//		/*Booking book= new Booking();
//		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("d-M-yyyy");
//		String date="26-08-2017";
//		LocalDate specificDate = LocalDate.parse(date, dtf);
//	
//		HashMap<Integer, Booking> bookMap=service.getBookingByDate(specificDate);
//			
//			System.out.println(bookMap);*/
//			/*User user1 = new User();
//			user1 = service.getUserList(10001);
//			System.out.println(user1);*/
//			/*int roomid= service.addRoom(room, 10004);
//			System.out.println(roomid);*/
//		/*	service.deleteRoom(14);
//			System.out.println("deleted");*/
//			HashMap<Integer, Booking> bookmap=service.getHotelBooking(10002);
//			System.out.println(bookmap);
//			
//		} catch (HBMSException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//}
