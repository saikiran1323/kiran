package com.capgemini.trainee.exception;

public class TraineeException extends Exception {

	private static final long serialVersionUID = 1L;

	public TraineeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TraineeException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
}
