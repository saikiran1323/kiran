package com.capgemini.trainee.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.trainee.bean.Trainee;
import com.capgemini.trainee.service.ITraineeService;

@Controller
public class TraineeController {

	@Autowired
	private ITraineeService traineeService;

	public ITraineeService getTraineeService() {
		return traineeService;
	}

	public void setTraineeService(ITraineeService traineeService) {
		this.traineeService = traineeService;
	}
	
	@RequestMapping("/showLoginPage")
	public String showLoginPage() {
		return "login";
	}
	
	@RequestMapping("/checkLogin")
	public String checkLogin(@RequestParam("userName") String traineeName,
			@RequestParam("password") String traineePass)
		{
			if(traineeName.equals("admin") && traineePass.equals("admin"))
				return "index";
			else
				return "login";
		}
	
	@RequestMapping("showHomePage")
	public String showHomePage(){
		return "index";
	}
	@RequestMapping("/showAddTrainee")
	public ModelAndView showAddTraineeForm() {
		Trainee trainee = new Trainee();
		return new ModelAndView("addTrainee", "trainee", trainee);
	}
	
	@RequestMapping("/addTrainee")
	public ModelAndView addTrainee(
			@ModelAttribute("trainee") @Valid Trainee trainee,
			BindingResult result) {
		ModelAndView mv = null;
		if(!result.hasErrors()){
			trainee=traineeService.addTrainee(trainee);
			mv=new ModelAndView("addTraineeSuccess");//creating mv obj and adding view
			mv.addObject("traineeId",trainee.getTraineeId());//adding model to mv object
			mv.addObject("traineeName",trainee.getTraineeName());//adding model to mv object
		}
		else{
			mv=new ModelAndView("addTrainee","trainee",trainee);
		}
		return mv;//returning mv obj
	}
	
	@RequestMapping("/showRetrieveTrainee")
	public ModelAndView showRetrieveTraineeForm(){
		Trainee trainee=new Trainee();
		ModelAndView mv = new ModelAndView("viewTrainee");
		mv.addObject("trainee",trainee);
		mv.addObject("isFirst","true");
		return mv;
		
	}
	
	@RequestMapping("/retrieveTrainee")
	public ModelAndView retrieveTrainee(@ModelAttribute("trainee") Trainee trainee) {
		ModelAndView mv = new ModelAndView();
		Trainee traineeBean= new Trainee();
		traineeBean = traineeService.retrieveTraineeDetails(trainee.getTraineeId());
		if (traineeBean != null) {
			mv.setViewName("viewTrainee");
			mv.addObject("traineeBean", traineeBean);
		} else {
			String msg = "Enter a Valid Id!!";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		}
		return mv;
	}
	
	@RequestMapping("/showRetrieveAllTrainee")
	public ModelAndView showRetrieveAllTrainee() {

		ModelAndView mv = new ModelAndView();
		List<Trainee> list = traineeService.getAllTraineesDetails();
		if (list.isEmpty()) {
			String msg = "There are no Trainees";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		} else {
			mv.setViewName("viewAllTrainee");
			// Add the attribute to the model
			mv.addObject("list", list);
		}
		return mv;
	}
	
	@RequestMapping("/showDeleteTrainee")
	public ModelAndView showDeleteTraineeForm(){
		Trainee trainee=new Trainee();
		ModelAndView mv = new ModelAndView("deleteTrainee");
		mv.addObject("trainee",trainee);
		mv.addObject("isFirst","true");
		return mv;
		
	}
	
	@RequestMapping("/deleteTrainee")
	public ModelAndView deleteTrainee(@ModelAttribute("trainee") Trainee trainee) {
		ModelAndView mv = new ModelAndView();
		Trainee traineeBean= new Trainee();
		traineeBean = traineeService.retrieveTraineeDetails(trainee.getTraineeId());
		if (traineeBean != null) {
			mv.setViewName("deleteTrainee");
			mv.addObject("traineeBean", traineeBean);
		} else {
			String msg = "Enter a Valid Id!!";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		}
		return mv;
	}
	
	@RequestMapping("/deleteTraineeDb")
	public ModelAndView deleteTraineeDb(@RequestParam("tId") String traineeId,Trainee traineeBean){
		ModelAndView mv = new ModelAndView();
		mv.addObject("traineeId",traineeId);
		/*Trainee traineeBean= new Trainee();
		traineeBean = traineeService.retrieveTraineeDetails(traineeId);
		System.out.println(traineeBean.getTraineeId());
		*/traineeService.deleteTrainee(traineeId);
		mv.setViewName("successpage");
		return mv;
	}
	
	@RequestMapping("/showModifyTrainee")
	public String showModifyTrainee(Model model) {
		model.addAttribute("trainee", new Trainee());
		return "showModifyOperation";
	}

	@RequestMapping("/showModifiedTrainee")
	public ModelAndView showModifiedTrainee(
			@ModelAttribute("trainee") Trainee trainee) {
		ModelAndView modelAndView = new ModelAndView("showModifiedTrainee",
				"trainee", traineeService.retrieveTraineeDetails(trainee
						.getTraineeId()));
		return modelAndView;
	}

	@RequestMapping("/modifyTrainee")
	public ModelAndView modifyTrainee(
			@ModelAttribute("trainee") @Valid Trainee trainee,
			BindingResult result) {

		ModelAndView modelAndView = null;

		if (!result.hasErrors()) {
			traineeService.modifyTrainee(trainee);
			return new ModelAndView("successpage");
		} else {
			modelAndView = new ModelAndView("showModifiedTrainee", "trainee",
					trainee);
		}
		return modelAndView;

	}
}