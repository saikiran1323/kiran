package com.capgemini.tcc.comcon;

import java.sql.*;

public class CommonConnection {
	public static Connection getCon()
	{
		Connection cn=null;
		try {
			Class.forName("oracle.jdbc.OracleDriver");
		cn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl", "trg606", "training606");
		
		System.out.println("connected");
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return cn;
		
	}

}
