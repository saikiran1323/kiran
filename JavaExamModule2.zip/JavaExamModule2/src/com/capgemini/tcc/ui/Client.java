package com.capgemini.tcc.ui;

import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.IdException;
import com.capgemini.tcc.service.IPatientSer;
import com.capgemini.tcc.service.PatientService;

public class Client {
	static Scanner sc=new Scanner(System.in);
	static IPatientSer iservice;
	static PatientService service;
	static Logger logger = Logger.getRootLogger();
	static PatientDAO pt=new PatientDAO();
	
	public static void main(String[] args) throws IdException, SQLException {
		PropertyConfigurator.configure("resources//log4j.properties");
		int patientId=0;
		PatientBean patient=null;
		
		PatientService service=new PatientService();
		System.out.println("1.Add Patient Information"
				+ "\n2. Search Patient by Id"
				+ "\n3.Exit");
	
		System.out.println("Enter your choice");
		int ch=sc.nextInt();
		switch(ch)
		{
		case 1:{
		
			patient=new PatientBean();
			System.out.println("Enter Patient Name ");
			String name=sc.next();
			patient.setPatientName(name);
			
			System.out.println("Enter Patient Age ");
			int age=sc.nextInt();
			patient.setAge(age);
			
			System.out.println("Enter Patient phone number ");
			String phone=sc.next();
			patient.setPhone(phone);
			
			System.out.println("Enter Description ");
			String des=sc.next();
			patient.setDescription(des);

			service.addPatientDetails(patient);
			
			break;}
		case 2:{
			//PatientBean bean =new PatientBean();
			System.out.println("Enter Patient Id to get details");
			int id=sc.nextInt();
			service.getPatientDetails(id);
			//patient.setPatientId(id);
			//service = new PatientService();
			//patient =
			//service.getPatientDetails(id);
			
			
			
			//patient.setPatientId(id);
			
			//service.getPatientDetails(patient);
			break;
			}
		case 3:try {
				System.out.println("System exit");
				System.exit(0);
			}
		catch(Exception e) {
				System.out.println(e);
			}
		
			break;
			}
		sc.close();
		

	}


}
