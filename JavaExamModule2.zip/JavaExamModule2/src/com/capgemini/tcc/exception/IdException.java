package com.capgemini.tcc.exception;

import java.util.Arrays;

public class IdException extends Exception{

	@Override
	public String toString() {
		return "There is no patient with this ID";
	}
	

}
