package com.capgemini.tcc.bean;

import java.sql.Date;
import java.time.LocalDate;

public class PatientBean {
	private int patientId;		
	private String patientName;
	private int age;
	private String phone;
	private String Description;
	private Date pdate;
	
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public Date getPdate() {
		return pdate;
	}
	public void setPdate(Date date) {
		this.pdate = date;
	}
/*	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Printing Donor Details \n");
		sb.append("Patient Name: " +patientName +"\n");
		sb.append("Patient Age: "+ age +"\n");
		sb.append("Phone Number: "+ phone +"\n");
		sb.append("Patient Description: "+ Description+"\n");
		sb.append("Patient Entry Date: "+ pdate);
		return sb.toString();
	}*/
	
	

}
