package com.capgemini.tcc.service;

import java.sql.SQLException;

import com.capgemini.tcc.bean.PatientBean;

public interface IPatientSer {
	int addPatientDetails(PatientBean patient);
	PatientBean getPatientDetails(int patientId) throws SQLException;

}
