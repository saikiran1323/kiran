package com.capgemini.tcc.service;

import java.sql.*;
import com.capgemini.tcc.dao.IPatientDAO;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.PatientDAO;


public class PatientService implements IPatientSer{
	IPatientDAO pdao;
	PatientBean bean=null;
	@Override
	public int addPatientDetails(PatientBean patient) {
		pdao=new PatientDAO();	
		int patSeq;
		patSeq= pdao.addpatientDetails(patient);
		return patSeq; 
		
	}

	@Override
	public PatientBean getPatientDetails(int patientId) throws SQLException {
		
		
		try
		{
			pdao=new PatientDAO();
			pdao.getPatientDetails(patientId);
			//bean=pdao.getPatientDetails(patientId);
			return bean;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}


	
	
}
