package com.capgemini.tcc.dao;

import java.sql.SQLException;

import com.capgemini.tcc.bean.PatientBean;

public interface IPatientDAO{
	
	int addpatientDetails(PatientBean patient);
	PatientBean getPatientDetails(int patientId) throws SQLException;
}