package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.comcon.CommonConnection;

public class PatientDAO implements IPatientDAO{

	Connection cn;
	PreparedStatement ps=null;		
	ResultSet rs;
	
	@Override
	public int addpatientDetails(PatientBean patient) {

		int patientId=0;
		int queryResult=0;
		try {
			cn=CommonConnection.getCon();
			ps=cn.prepareStatement("Insert into patientc values(emp_sequence.nextval,?,?,?,?,sysdate)");
			ps.setString(1, patient.getPatientName());
			ps.setInt(2, patient.getAge());
			ps.setString(3, patient.getPhone());
			ps.setString(4, patient.getDescription());

			ps.executeUpdate();
			//System.out.println("Patient Informatin stored successfully for "+patient.getPatientId());
			ps=cn.prepareStatement("select emp_sequence.currval from dual");
			rs=ps.executeQuery();
			if(rs.next())
			{
				patientId=rs.getInt(1);
				System.out.println("Patient Informatin stored successfully for "+patientId);
			}
		}catch(Exception e) {
				//System.out.println(e);
		          e.printStackTrace();	
		}
		
		return patientId;
	}

	@Override
	public PatientBean getPatientDetails(int patientId) throws SQLException {
		
		PatientBean patient=null;

		try {
			
			cn=CommonConnection.getCon();
			Statement st=cn.createStatement();
			ResultSet rs=st.executeQuery("select PATEINT_NAME,AGE,PHONE,DESCRIPTION,ENTRYDATE from patientc where PATIENT_ID="+patientId);
		//ps=cn.prepareStatement("select PATEINT_NAME,AGE,PHONE,DESCRIPTION,ENTRYDATE from patientc where PATIENT_ID=?");
	   // String sql = "SELECT PATIENT_ID FROM patientc";        
	   // PreparedStatement ps1 = cn.prepareStatement(sql);
	    

	   /* ResultSet rs2 = ps.executeQuery();

	    List<Integer> matchingNames = new ArrayList<>();
	    while (rs2.next())
	    {
	        int id = rs2.getInt("patient_id");
	        matchingNames.add(id);
	    }       
	    int ct=0;
	    for (int pid: matchingNames)
	    {
	        if(pid==patient.getPatientId())
	        	ct++;
	    }*/
	   // System.out.println(ct);
		//ps.setInt(1, patient.getPatientId());
			//st.setInt(1, patientId);
		//rs=st.executeQuery();
		//ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			System.out.println(rs.getString(1)+" "+rs.getInt(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getDate(5));
	}
		System.out.println();
	}catch(Exception ae) {
		System.out.println(ae);
	}

			
		
/*		//cn=CommonConnection.getCon();
		PatientBean bean=new PatientBean();
		ps=cn.prepareStatement("select PATEINT_NAME,AGE,PHONE,DESCRIPTION,ENTRYDATE from patientc where PATIENT_ID=?");
		ps.setInt(1, bean.getPatientId());
		ps.executeUpdate();
		rs=ps.executeQuery();
	    //ResultSet rs=stmt.executeQuery(sql);
		while(rs.next())
		{
			System.out.println("Name of the Patient : "+rs.getString(2)+"\n"+"Age : "+rs.getInt(3)+"\n"+"Phone Number  : "+rs.getString(4)+"\n"+"Description : "+rs.getString(5)+"\n"+"Consultation Date : "+rs.getDate(6));
		}
		//ps.executeUpdate();
		//ResultSet rs=ps.executeQuery();
		//while(rs.next()) {
		//	System.out.println(rs.getString(1)+" "+rs.getInt(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getDate(5));
	//}
	
		while(rs.next())
		{
			bean=new PatientBean();
			bean.setPatientName(rs.getString("PATEINT_NAME"));
			bean.setAge(rs.getInt("AGE"));
			bean.setPhone(rs.getString("PHONE"));
			bean.setDescription(rs.getString("DESCRIPTION"));
			bean.setPdate(rs.getDate("ENTRYDATE"));
			
		}*/
		
		return patient;
	}
	
	

}
