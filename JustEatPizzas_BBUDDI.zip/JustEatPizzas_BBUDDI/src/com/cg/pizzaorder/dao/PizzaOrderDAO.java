package com.cg.pizzaorder.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.service.PizzaException;

public class PizzaOrderDAO implements IPizzaOrderDAO{
	Map<Integer,PizzaOrder> pizzaEntry=new HashMap<Integer,PizzaOrder>();
	Map<Integer,Customer> customerEntry=new HashMap<Integer,Customer>();
	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza)throws PizzaException {
		pizzaEntry.put(pizza.getOrderId(), pizza);
		customerEntry.put(customer.getCustomerId(), customer);
		return pizza.getOrderId();
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid)throws PizzaException {
		if(pizzaEntry.containsKey(orderid))
			return pizzaEntry.get(orderid);
		else
			throw new PizzaException("order id not found");
	}

}
