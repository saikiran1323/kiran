package com.cg.pizzaorder.bean;

import com.cg.pizzaorder.service.PizzaException;

public class PizzaOrder {
	private int orderId;
	private int customerId;
	private double totalPrice;
	
	//this constructor sets the total price of the order
	public PizzaOrder(String toppings)throws PizzaException {
		this.totalPrice=350;
		if(toppings.equalsIgnoreCase("capsicum"))
			totalPrice+=30;
		else if(toppings.equalsIgnoreCase("mushroom"))
			totalPrice+=50;
		else if(toppings.equalsIgnoreCase("jalapeno"))
			totalPrice+=70;
		else if(toppings.equalsIgnoreCase("paneer"))
			totalPrice+=85;
		else
			throw new PizzaException("toppings not present");
	}
	public PizzaOrder() {
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	
}
