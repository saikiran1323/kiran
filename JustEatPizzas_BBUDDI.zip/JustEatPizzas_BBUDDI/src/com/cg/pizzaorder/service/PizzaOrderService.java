package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.PizzaOrderDAO;

public class PizzaOrderService implements IPizzaOrderService{
	private static PizzaOrderDAO pizzadao=new PizzaOrderDAO();
	private double price;
	
	public PizzaOrderService() {
	}
	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza)throws PizzaException {
		int customerid=(int)(Math.random()*10000);
		customer.setCustomerId(customerid);
		pizza.setCustomerId(customerid);
		pizza.setOrderId((int)(Math.random()*10000));
		price=pizza.getTotalPrice();
		return pizzadao.placeOrder(customer, pizza);
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid)throws PizzaException {
		return pizzadao.getOrderDetails(orderid);
	}
	public double getPrice() {
		return price;
	}
	
}
