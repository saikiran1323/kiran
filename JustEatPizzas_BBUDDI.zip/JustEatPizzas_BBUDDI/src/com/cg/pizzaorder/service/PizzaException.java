package com.cg.pizzaorder.service;

public class PizzaException extends RuntimeException {
	public PizzaException(String s)
	{
		super(s);
	}
}
