package com.cg.pizzaorder.junit;



import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.IPizzaOrderDAO;
import com.cg.pizzaorder.dao.PizzaOrderDAO;

public class Teastdao {

	@Test
	public void testplaceOrder(){
		IPizzaOrderDAO dao=new PizzaOrderDAO();
		double expected=380;
		int orderid=dao.placeOrder(new Customer("ganesh","dallas","7555555555"),new PizzaOrder("capsicum"));
		assertTrue(dao.getOrderDetails(orderid).getTotalPrice()==expected);
	}

}
