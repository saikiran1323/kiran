package com.cg.pizzaorder.ui;

import java.time.LocalDate;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.service.PizzaOrderService;
import com.cg.pizzaorder.service.IPizzaOrderService;
public class Client {

	private static Scanner sc;

	public static void main(String[] args) {
		IPizzaOrderService service=new PizzaOrderService();
		sc = new Scanner(System.in);
		while(true){
		System.out.println("Menu\n1)Place Order\n2)Display Order\n3)Exit");
		int i=sc.nextInt();
		if(i==1){
			System.out.print("Enter the name of the customer : ");
			String name="";
			while(true){
				name=sc.next();
				if(name.trim().length()==0)//checks whether name is entered or not
					System.out.println("enter name correctly");
				else
					break;
			}
			System.out.print("Enter customer address : ");
			String address;
			while(true){
				address=sc.next();
				if(address.trim().length()==0)//checks whether address is entered or not
					System.out.println("enter address correctly");
				else
					break;
			}
			System.out.print("Enter customer phone number : ");
			String number=null;
			while(true){
			number = sc.next();
			if(Pattern.matches("[6789]\\d{9}", number))//checks whether phone number is correct
				break;
			else
				System.out.println("enter phone number correctly");
			}
			try{
				System.out.println("Avaliable toppings\n1.capsicum\n2.mushroom\n3.jalapeno\n4.paneer");
				System.out.print("Enter name of the type of Pizza Topping preferred : ");
				String toppings=sc.next();
				int orderid=service.placeOrder(new Customer(name,address,number),new PizzaOrder(toppings));
				System.out.println("Price : "+service.getPrice());
				System.out.println("Order Date : "+LocalDate.now());
				System.out.println("Pizza Order successfully placed with Order Id: "+orderid);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
				
		}
		else if(i==2){
			System.out.print("enter order id ");
			int orderid=sc.nextInt();
			PizzaOrder order;
			try {
				order = service.getOrderDetails(orderid);
				System.out.println("order id : "+order.getOrderId()+"\ncustomer id: "+order.getCustomerId()+"\nTotal price : "+order.getTotalPrice());
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
		else if(i==3){
			System.exit(0);
		}
		else{
			System.out.println("enter correct option");
		}
	}
}

}
