package com.cg.util;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DbUtil {
	static Connection conn = null;

	private DbUtil() {

	}

	public static Connection getInstance() {
		try {
			FileInputStream fis = new FileInputStream("resource/jdbc.properties");
			Properties prop = new Properties();
			prop.load(fis);
			if (conn == null) {
				Class.forName(prop.getProperty("driver"));
				conn = DriverManager.getConnection(prop.getProperty("url"), prop.getProperty("username"),
						prop.getProperty("password"));
				return conn;
			}
			else{
				return conn;
			}
		} catch (Exception e) {
				return null;
		}
	}

}
