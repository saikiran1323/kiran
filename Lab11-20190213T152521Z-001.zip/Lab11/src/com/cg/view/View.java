package com.cg.view;

import java.util.List;
import java.util.Scanner;

import com.cg.exception.MobileNotFoundException;
import com.cg.model.Mobile;
import com.cg.model.MobileShop;
import com.cg.service.MobileServiceImpl;

//import com.cg.exception.EmployeeNotFoundException;
//import com.cg.model.Employee;
//import com.cg.service.EmployeeService;
//import com.cg.service.EmployeeServiceImpl;

public class View {

	
		static Scanner sc = new Scanner(System.in);

		public static void main(String[] args) {
			int flag = 0;

			do {
				System.out.println("Enter Username");
				String name = sc.next();

				System.out.println("Enter Password");
				String pass = sc.next();

				if (name.equals("admin") && pass.equals("admin")) {
					flag = 1;
					int choice = 0;
					do {
						System.out.println("1: insert data");
						System.out.println("2: list all");
						System.out.println("3: delete data");
						System.out.println("4: Search");
						System.out.println("5: exit");
						choice = sc.nextInt();
						switch (choice) {
						case 1: {
							insertMethod();
							break;
						}
						case 2: {
							listAll();
							break;
						}
						case 3: {
							deleteMethod();
							break;
						}
						case 4: {
							searchMethod();
							break;
						}
						case 5: {
							System.out.println("You are exited");
							System.exit(0);
						}
						default:
							System.err.println("Wrong Choice");
						}
					} while (choice != 5);
				}
				if (flag == 0) {
					System.out.println("Invalid data !! Please try again");
				}

			} while (flag == 0);
		}

		private static void searchMethod() {
			MobileShop mobile = new MobileShop();
			System.out.println("Enter your price range");
			int price = sc.nextInt();
			int price1 = sc.nextInt();
			mobile.setPrice(price);
			mobile.setPrice2(price1);
			MobileServiceImpl mobSer = new MobileServiceImpl();
			List<MobileShop> list = mobSer.searchMobile(mobile);
			System.out.println("Mobile_Id"+" "+"Mobile_Name"+" "+"Price"+" "+"Quantity");
			for(MobileShop m : list) {
				System.out.println(m.getMobileid()+" "+m.getName()+" "+m.getPrice()+" "+m.getQuantity());
			}
		}
			
		private static void listAll() {
			MobileServiceImpl mobSer = new MobileServiceImpl();
			List<MobileShop> list = mobSer.listMobile();
			System.out.println("Mobile_Id"+" "+"Mobile_Name"+" "+"Price"+" "+"Quantity");
			for(MobileShop m : list) {
				System.out.println(m.getMobileid()+" "+m.getName()+" "+m.getPrice()+" "+m.getQuantity());
			}
		}
			

		private static void deleteMethod() {
			MobileShop mob = new MobileShop();
			boolean flag = false;
			do {
				flag = false;
				System.out.println("Enter id");
				int id = sc.nextInt();
				if (id < 1000 || id > 10000) {
					flag = true;
					System.err.println("Invalid Mobile Id");
					continue;
				}
				mob.setMobileid((id));
			} while (flag);
			
			MobileServiceImpl mobSer = new MobileServiceImpl();
			try {
			if(mobSer.deleteMobile(mob) > 0) {
				System.out.println("Mobile Deleted");
			}
			}catch(MobileNotFoundException e) {
				System.err.println(e.getMessage());
			}
			
		}
		

		public static void insertMethod() {

			Mobile mob = new Mobile();
			boolean flag = false;
			do {
				flag = false;
				System.out.println("Enter Customer name");
				String name = sc.next();
				if(!name.matches("^[A-Z][A-Za-z]*.{3,20}")) {
					flag = true;
					System.err.println("Invalid Name");
					continue;
				}
				mob.setName(name);
			}while(flag);
			do {
				flag = false;
				System.out.println("Enter Email Id");
				String email = sc.next();
				if(!email.matches("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")) {
					flag = true;
					System.err.println("Invalid Email");
					continue;
				}
				mob.setEmail(email);
			}while(flag);
			do {
				flag = false;
				System.out.println("Enter Phone Number");
				String number =sc.next();
				if (!number.matches("^[0-9]{10}$")) {
					flag = true;
					System.err.println("Invalid Phone Number");
					continue;
				}
				mob.setPhoneNumber(number);
			} while (flag);
			do {
				flag = false;
				System.out.println("Enter MobileId");
				int id = sc.nextInt();
				if (id < 1000 || id > 10000) {
					flag = true;
					System.err.println("Invalid Mobile Id");
					continue;
				}
				mob.setMobileId(id);
			} while (flag);
			
			MobileServiceImpl mobSer = new MobileServiceImpl();
			if(mobSer.insertMobile(mob) > 0) {
				System.out.println("Purcahse Successfull");
			}
			else {
				System.err.println("Internal error");
			}
			

	}

}
