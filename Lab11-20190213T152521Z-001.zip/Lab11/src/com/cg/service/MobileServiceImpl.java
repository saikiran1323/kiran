package com.cg.service;

import java.util.List;

import com.cg.dao.MobileDaoImpl;
import com.cg.exception.MobileNotFoundException;
import com.cg.model.Mobile;
import com.cg.model.MobileShop;

public class MobileServiceImpl implements MobileService {
	MobileDaoImpl mobDaoImpl = new MobileDaoImpl();

	@Override
	public int insertMobile(Mobile mobile) {
		return mobDaoImpl.insertMobile(mobile);
	}

	@Override
	public int deleteMobile(MobileShop mobile) throws MobileNotFoundException {
		return mobDaoImpl.deleteMobile(mobile);
	}

	@Override
	public List<MobileShop> listMobile() {
		return mobDaoImpl.listMobile();
	}

	@Override
	public List<MobileShop> searchMobile(MobileShop mobile) {
		return mobDaoImpl.searchMobile(mobile);
	}

}
