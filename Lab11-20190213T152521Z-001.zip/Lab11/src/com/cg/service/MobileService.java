package com.cg.service;

import java.util.List;

import com.cg.exception.MobileNotFoundException;
import com.cg.model.Mobile;
import com.cg.model.MobileShop;

public interface MobileService {

	public int insertMobile(Mobile mobile);

	public int deleteMobile(MobileShop mobile) throws MobileNotFoundException;

	public List<MobileShop> listMobile();
	
	public List<MobileShop> searchMobile(MobileShop mobile);
}
