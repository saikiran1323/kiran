package com.cg.constants;

public interface JdbcQuery {
	public static final String INSERT="insert into purchasedetails values(prodId_seq.nextval,?,?,?,sysdate,?)";
	String UPDATE ="update mobiles set quantity = quantity-1 where mobileid = ?";
	String SELECT = "select * from mobiles";
	String DELETE = "delete from mobiles where mobileid = ?";
	String SELECT1 = "select * from mobiles where price between ? and ?";
}
