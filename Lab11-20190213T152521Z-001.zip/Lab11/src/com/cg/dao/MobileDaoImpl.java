package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.cg.constants.JdbcQuery;
import com.cg.exception.MobileNotFoundException;
import com.cg.model.Mobile;
import com.cg.model.MobileShop;
import com.cg.util.DbUtil;


public class MobileDaoImpl implements MobileDao {
	Connection conn= null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	List<MobileShop> list = new ArrayList<MobileShop>();
	@Override
	public int insertMobile(Mobile mobile) {
		conn = DbUtil.getInstance();
		int flag = 0;
		try {
			ps=conn.prepareStatement(JdbcQuery.INSERT);
			ps.setString(1, mobile.getName());
			ps.setString(2, mobile.getEmail());
			ps.setString(3, mobile.getPhoneNumber());
			ps.setInt(4,mobile.getMobileId());
			flag = ps.executeUpdate();
			ps = conn.prepareStatement(JdbcQuery.UPDATE);
			ps.setInt(1, mobile.getMobileId());
			flag = ps.executeUpdate();
		} catch (Exception e) {
          e.printStackTrace();
		}
		return flag;
	}

	@Override
	public int deleteMobile(MobileShop mobile) throws MobileNotFoundException {
		conn = DbUtil.getInstance();
		int flag = 0;
		try {
			ps = conn.prepareStatement(JdbcQuery.DELETE);
			ps.setInt(1, mobile.getMobileid());
			flag = ps.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		if(flag!=1) {
			throw new MobileNotFoundException("No Mobile Id Found");
		}
		return flag;
	}

	@Override
	public List<MobileShop> listMobile() {
		conn = DbUtil.getInstance();
		try {
			ps = conn.prepareStatement(JdbcQuery.SELECT);
			rs = ps.executeQuery();
			while(rs.next()) {
				MobileShop ms = new MobileShop();
				ms.setMobileid(rs.getInt("mobileid"));
				ms.setName(rs.getString("name"));
				ms.setPrice(rs.getInt("price"));
				ms.setQuantity(rs.getString("quantity"));
				list.add(ms);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return list;
		
	}

	@Override
	public List<MobileShop> searchMobile(MobileShop mobile) {
			conn = DbUtil.getInstance();
			try {
				ps=conn.prepareStatement(JdbcQuery.SELECT1);
				ps.setInt(1, mobile.getPrice());
				ps.setInt(2, mobile.getPrice2());														
				rs = ps.executeQuery();
				while(rs.next()) {
					MobileShop ms = new MobileShop();
					ms.setMobileid(rs.getInt("mobileid"));
					ms.setName(rs.getString("name"));
					ms.setPrice(rs.getInt("price"));
					ms.setQuantity(rs.getString("quantity"));
					list.add(ms);
				}
			} catch (Exception e) {
	          e.printStackTrace();
			}
			return list;
		}
	
	
}
