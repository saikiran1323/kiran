package com.cg.exception;

public class MobileNotFoundException extends Exception {

	public MobileNotFoundException(String msg) {
		super(msg);
	}
}
